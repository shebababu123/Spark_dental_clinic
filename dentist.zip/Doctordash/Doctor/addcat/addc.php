<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Add Catrgory</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="addc/img/favicon.png" rel="icon">
  <link href="addc/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Roboto:100,300,400,500,700|Philosopher:400,400i,700,700i" rel="stylesheet">

  <!-- Bootstrap css -->
  <!-- <link rel="stylesheet" href="css/bootstrap.css"> -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.theme.default.min.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/modal-video/css/modal-video.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/table.css" rel="stylesheet">
<style>
@import url(https://fonts.googleapis.com/css?family=Roboto:300);


.form {
  width: 360px;
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 360px;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: center;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #FFF;
  width: 100%;
  border-color: #4CAF50;
  border-radius:50px;
  padding: 15px;
  color: #4CAF50;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form button:hover,.form button:active,.form button:focus {
  background: #43A047;
  color: #FFF;
  border-color: #FFF;
  
}


</style>
 
    <script>
    function validate(e)
{
  
    var category=document.getElementById("category").value;
   
    if(category == "")
    {

    alert("Specify catetgory");
    document.getElementById("category").focus();
    return false;
    }
}
</script>
</head>


<body>

  <header id="header" class="header header-hide">
    <div class="container">
    

      <div id="logo" class="pull-left">
        
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="#body"><img src="img/logo.png" alt="" title="" /></a>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
        

        </ul>
      </nav>

    </div>
  </header><!-- #header -->

  <section id="hero" class="wow fadeIn">
    <div class="hero-container">

      
      <a href="#get-started" class="btn-get-started scrollto">ADD CATEGORY</a>
      <table class="rwd-table">
          <tr>
               <th>Existing Categorys</th>
        </tr>
         
         <?php 
    include "connection.php";
    $query="SELECT * FROM `add_category`";
    $result = mysqli_query($db,$query) or die(mysqli_error());
    if ($result->num_rows > 0)
    {
                          
    while($row = $result->fetch_assoc()) 
    {
      
     ?><tr><td data-th="Movie Title"><?php echo $row["catname"]; ?></td> </tr> 

    <?php } } ?>
        
       </table>
    </div>
  </section><!-- #hero -->

  
  <section id="get-started" class="padd-section text-center wow fadeInUp">

<center><div class="container">
  <div class="section-title text-center">

    <h2> </h2>
    <div>
      <div class="login-page" style="padding-top:150px;">
          <div class="form">
            <form class="login-form" action="category.php" method="POST">
                <br>
               
                <br>
                <input type="text" name="category"  autocomplete="off" id="category" placeholder="Enter category"/>
                <br>
                <br>
                <button type="submit" name="submit" onclick="return validate(this)">ADD CATEGORY</button>
            </form>
           </div>
         </div>
         </div>
       </div>
     </div>
</div>
</div>
</center>

    <div class="container">
      <div class="row">

        
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/modal-video/js/modal-video.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="addc/contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="addc/js/main.js"></script>
  

</body>
</html>


