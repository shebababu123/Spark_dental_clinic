<?php



// connect to the database
$dn= mysqli_connect('localhost', 'root', '','farmers_portal');
+
    $category=$_POST['category'];
    $sq="INSERT INTO `add_category`(`catname`) VALUES ('$category')";
    $ch=mysqli_query($dn,$sq);
    if($ch)
    {
        echo" <script>
          alert('CATEGORY ADDED');
          </script>";
          echo "<script>setTimeout(\"location.href = '/pr/admin/addcat/addc.php';\",500);</script>";
    }
    else
    {
        echo" <script>
        alert('Category Already Exist');
        </script>";
        echo "<script>setTimeout(\"location.href = '/pr/admin/addcat/addc.php';\",500);</script>";
    }
    


mysqli_close($dn);
?>
