<?php
session_start();
if(isset($_SESSION['loginid'])){
	$d=$_SESSION['loginid'];
include('dbconnect.php');
}
?>
<html>
<head>
<link rel="stylesheet" href="\DentalClinicManagement\dentist\Doctordash\Doctor\viewappointment\css\customerview.css">
<nav id="nav-menu-container">
        <ul class="nav-menu">
          

        </ul>
      </nav>
</head>
<body>
 <table>
 
     <thead>
            <tr>
               <th colspan="5" style="font-size:35px;color:black;">Appointments</th>
            </tr>
            <tr style="background-color:black; color:white;">
                <th>Index.</th>
                <th>Patient Id</th>
                <th>Appointment Date</th>
                <th>Time</th>
                
                
            </tr>
    </thead>
          <tbody>
                          <?php 
                          include "dbconnect.php";
                          $query="select Doctor_id from  tbl_adddoctor where Login_id='$d'";
                          $result = mysqli_query($con,$query) or die(mysqli_error());
                         if ($result->num_rows > 0)
                          {
                            $i=1;
                            while($row = $result->fetch_assoc()) 
                            {
                                $doctorid=$row['Doctor_id'];
                                
                                $q2="select * from tbl_appointdoc where Doctor_id='$doctorid'";
                                $s2=mysqli_query($con,$q2);
                                while ($r2=mysqli_fetch_array($s2)) {
                                  $dat=$row['Appoint_date'];
                                  $tm=$row['Time_id'];
                                  $pid=$row['Patient_id'];
                                  $aid=$row['Appoint_id'];
                               
                                $qr=mysqli_query($con,"select * from tbl_addtimeslot where Time_id='$tm'");
                                $rs=mysqli_fetch_array($qr);
                                $Tim=$rs['Slots'];

                      
                           echo "<tr style='color:black;'><td>".$i."</td><td>$pid</td><td>$dat</td><td>$Tim</td>";?>
            <td>
            <a href="" ><button class="case">Case Record</button></a>
            <a href="" ><button class="his">View History</button></a>
            <a href="update.php?id=<?php echo $aid;?>" ><button class="Edit">Consulted</button></a>
            </td>
            </tr>
                          <?php
                           ++$i;
                            }
                        }
                            
                          }
                          else
                          {
                            echo '<script language="javascript">';
                            echo 'alert("No appointments Found")';
                            echo '</script>';
                          }
                          $con->close();
                          ?>
                        </tbody>
                      </table>
<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/pr/customer/js/jquery-3.1.1.min.js"></script>
<script src="/pr/customer/js/js"></script>
<script>

</script>
</body>
</html>
