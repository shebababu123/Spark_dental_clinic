<?php 
 include 'dbconnect.php';
  $id=$_GET['pa'];
 if(isset($id))
  {
  
  // Check record exists
  $query = "UPDATE `tbl_appointdoc` SET Status=2 WHERE Appoint_id='$id'";
   $result = mysqli_query($con,$query);

  if ($result)
  {
   
        
        echo '<script type="text/javascript">';
        echo 'alert("Consulted and move to prescription")';
        echo '</script>';
        echo "<script>setTimeout(\"location.href = 'DentalClinicManagement/dentist/Doctordash/Doctor/viewappointment/viewappointment.php';\",0);</script>";
    
           
   
     }
    }

?>