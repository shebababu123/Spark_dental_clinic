
<html>
<head>
<link rel="stylesheet" href="\DentalClinicManagement\dentist\Doctordash\Doctor\viewavailtime\css\customerview.css">
<nav id="nav-menu-container">
        <ul class="nav-menu">
          

        </ul>
      </nav>
</head>
<body>
 <table>
 
     <thead>
            <tr>
               <th colspan="8" style="font-size:35px;color:black;"> My Available time</th>
            </tr>
            <tr style="background-color:black; color:white;">
                <th>Index.</th>
                <th>Month</th>
                <th>Dates</th>
                <th>Time</th>
               <th>action</th>
            </tr>
    </thead>
          <tbody>
                          <?php 
                          include "dbconnect.php";
                          $query="SELECT * from tbl_doctoravail";
                          $result = mysqli_query($con,$query) or die(mysqli_error());
                         if ($result->num_rows > 0)
                          {
                            $i=1;
                            while($row = $result->fetch_assoc()) 
                            {
                               
                           echo "<tr style='color:black;'><td>".$i."</td><td>".$row["Month"]."</td><td>".$row["Date"]."</td><td>".$row["Timeofavailable"]."</td>";?>
                          <td>
                          <a href="Updateavail.php?id=<?php echo $row["Avail_id"]; ?>" ><button class="up">Update</button></a>
                           </td>
                           </tr>
            
                          <?php
                           ++$i;
                            }
                          }
                        
                            
                          else
                          {
                            echo '<script language="javascript">';
                            echo 'alert("No records Found")';
                            echo '</script>';
                          }
                          $con->close();
                          ?>
                        </tbody>
                      </table>
<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/pr/customer/js/jquery-3.1.1.min.js"></script>
<script src="/pr/customer/js/js"></script>
<script>

</script>
</body>
</html>
