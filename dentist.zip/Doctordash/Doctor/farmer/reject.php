<?php 
$db = mysqli_connect('localhost', 'root', '', 'farmers_portal') or die ("Error connecting to Database".$db->connect_error);
  $id = $_GET['id'];
 
 if(isset($id))
  {
  
  // Check record exists
  $query = "SELECT * FROM `farmer_reg` WHERE Sid='$id'";
   $result = mysqli_query($db,$query);

  if ($result->num_rows > 0)
  {
     // Delete record
    $del = "DELETE FROM `farmer_reg` WHERE Sid='$id'";
    $res=mysqli_query($db,$del);
    if($res)
    {
    
        echo '<script type="text/javascript">';
        echo 'alert("User Rejected")';
        echo '</script>';
        echo "<script>setTimeout(\"location.href = '/pr/Admin/admin.php';\",200);</script>";
    
    }
   
     }
    }

// echo 0;
// exit;
?>