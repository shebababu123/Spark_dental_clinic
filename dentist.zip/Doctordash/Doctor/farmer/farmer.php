<html>
<head>
<link rel="stylesheet" href="css/farmer.css">

</head>
<body>
<nav id="nav-menu-container">
        <ul class="nav-menu">
          

        </ul>
      </nav>
<table>
 
 <thead>
        <tr>
           <th colspan="9">Requested Farmers</th>
        </tr>
        <tr style="background-color:#414141e8;">
            <th>Index.</th>
            <th>Name</th>
            <th>Address</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Adhar</th>
            <th>Kisan</th>
            <th colspan="2" style="text-align:left;">Action</th>
        </tr>
</thead>
<tbody>
                      <?php 
                      include "connection.php";
                      $query="SELECT * FROM `farmer_reg` WHERE status=0";
                      $result = mysqli_query($db,$query) or die(mysqli_error());
                     if ($result->num_rows > 0)
                      {
                        $i=1;
                        while($row = $result->fetch_assoc()) 
                        {
                          echo "<tr><td>".$i."</td><td>".$row["Sname"]."</td><td>".$row["Address"]."</td><td>".$row["Phone"]."</td><td>".$row["Email"]."</td><td>".$row["Adhar no."]."</td><td><a href='"."/pr/".$row["Kisan"]."'>".$row["Kisan"]."</a></td>";?>
                      <td>
                    <a href="/pr/Admin/farmer/reject.php?id=<?php echo $row["Sid"]; ?>" ><button class="Block">Reject</button></a>
                    <a href="/pr/Admin/farmer/accept.php?id=<?php echo $row["Sid"]; ?>" ><button class="Edit" id="<?php echo $row["farmer_id"]; ?>">Accept</button></a>
                      </td><td></td>
                      <?php
                       ++$i;
                        }
                        
                      }
                      else
                      {
                        
                      }
                      $db->close();
                      ?>
                  </tbody>
                  </table>

         
<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/printer/Admin/student/js/jquery-3.1.1.min.js"></script>
<script src="js/farmer.js"></script>

</body>
</html>
