<?php 
$db = mysqli_connect('localhost', 'root', '', 'farmers_portal') or die ("Error connecting to Database".$db->connect_error);
  $id = $_GET['id'];
 
 if(isset($id))
  {
  
  // Check record exists
  $query = "SELECT * FROM `farmer_reg` WHERE Sid='$id'";
   $result = mysqli_query($db,$query);

  if ($result->num_rows > 0)
  {
     // update status
    $del = "UPDATE farmer_reg SET status=1 WHERE Sid= '$id'";
    $res=mysqli_query($db,$del);
    if($res)
    {
      $ins ="INSERT INTO `login`(`User_id`, `Login_id`,`user_name`, `Password`,`user_type`)"
      ." SELECT NULL, `Sid`,`Sname`, `Password`,'1'"
      ." FROM farmer_reg WHERE Sid= '$id'";
     $result1 = mysqli_query($db,$ins);
     if($result1)
     {
     
        
        echo '<script type="text/javascript">';
        echo 'alert("User Accepted")';
        echo '</script>';
        echo "<script>setTimeout(\"location.href = '/pr/Admin/admin.php';\",200);</script>";
      
     }
           
    }
   
     }
    }

?>