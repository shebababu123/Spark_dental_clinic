<?php
include('dbconnect.php');
 
 session_start();
if(isset($_SESSION['loginid'])){
  
  $id=$_SESSION['loginid'];
  
        $s3=mysqli_query($con,"select Doctor_id from tbl_adddoctor where Login_id='$id'") or die(mysqli_error($con));
			  $r3=mysqli_fetch_array($s3);
        $r=$r3['Doctor_id'];
                
}
 ?>
<html>
<head>
<link rel="stylesheet" href="\DentalClinicManagement\dentist\Doctordash\Doctor\leave\leavestatus\css\customerview.css">

</head>
<body>
 <table>
 
     <thead>
            <tr>
               <th colspan="5"style="font-size:30px;color:black;">Leave Status</th>
               <th></th>
            </tr>
            <tr style="background-color:black;">
            <th>Index.</th>
                <th>Name</th>
                <th>Date</th>
                <th>Reason</th>
                <th colspan="6" style="text-align:left;">Status</th>
                
            </tr>
    </thead>
    <tbody>
                         
                          <?php 
                          include "dbconnect.php";
                          $query="SELECT a.D_name,b.Doctor_id,b.Date,b.Reason,b.Leave_id,b.Status from tbl_adddoctor a join tbl_leave b on a.Doctor_id=b.Doctor_id and b.Doctor_id='$r'";
                          $result = mysqli_query($con,$query);
                         if ($result)
                          {
                            $i=1;

                            while($row = $result->fetch_assoc()) 
                            {

                              if($row["Status"] == 0)
                              {
                                $status="Pending";
                              }
                              else if ($row["Status"] == 1)
                              {
                                $status="Approved";
                              }
                              else
                              {
                                $status="Rejected";
                              }

                             
                              echo "<tr><td>".$i."</td><td>".$row["D_name"]."</td><td>".$row["Date"]."</td><td>".$row["Reason"]."</td><td>".$status."</td>"."<td></td>"."<td></td>";?>
                          <td></td><td></td>
                          <?php
                           ++$i;
                            
                          }
                        }
                          
                          else
                          {
                           
                          }
                          $con->close();
                          ?>
                      </tbody>
                      </table>



<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/printer/Admin/student/js/jquery-3.1.1.min.js"></script>
<script src="js/leavestatus.js"></script>
<script>

</script>
</body>
</html>
