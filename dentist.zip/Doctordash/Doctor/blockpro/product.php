<html>
<head>
<link rel="stylesheet" href="css/supplier.css">

</head>
<nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="/pr/admin/admin.php">Home</a></li>

        </ul>
      </nav>
<body>
 <table>
 
     <thead>
            <tr>
               <th colspan="5">Added Products</th>
            </tr>
            <tr style="background-color:#575757e8;">
                <th>Index.</th>
                <th>Category Name</th>
                <th>Product</th>
                <th colspan="2" style="text-align:left;">Action</th>
            </tr>
    </thead>
    <tbody>
    <?php 
                          include "connection.php";
                          $query="select a.catname,b.pro_name,b.status,b.Pid from add_category a join add_product b on b.Cid=a.cid";
                          $result = mysqli_query($db,$query) or die(mysqli_error());
                         if ($result->num_rows > 0)
                          {
                            $i=1;
                            while($row = $result->fetch_assoc()) 
                            {
                              echo "<tr><td>".$i."</td><td>".$row["catname"]."</td><td>".$row["pro_name"]."</td>";
                              if($row["status"] ==1)
                              {
                                $a="Block";
                                $link="/pr/Admin/blockpro/block.php?id=".$row["Pid"];
                              }
                              else
                              {
                                $a="Unblock"; 
                                $link="/pr/Admin/blockpro/unblock.php?id=".$row["Pid"];
                              }
                              ?>
                          <td>
                          <a href="<?php echo $link; ?>"><button class="<?php echo $a; ?>" ><?php echo $a; ?></button></a>
                          
                          </td><td></td>
                          <?php
                           ++$i;
                            }
                            
                          }
                          else
                          {
                           
                          }
                          $db->close();
                          ?>
                      </tbody>
                      </table>



<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/printer/Admin/student/js/jquery-3.1.1.min.js"></script>
<script src="js/supplier.js"></script>
<script>

</script>
</body>
</html>
