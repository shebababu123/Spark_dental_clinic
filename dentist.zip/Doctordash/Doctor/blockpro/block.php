<?php 
$db = mysqli_connect('localhost', 'root', '', 'farmers_portal') or die ("Error connecting to Database".$db->connect_error);
  $id = $_GET['id'];
 
 if(isset($id))
  {
  
  // Check record exists
  $query = "SELECT * FROM `add_product` WHERE Pid='$id'";
   $result = mysqli_query($db,$query);

  if ($result->num_rows > 0)
  {
     // Delete record
    $del = "update `add_product` set status=0 where Pid='$id'";
    $res=mysqli_query($db,$del);
   
      if($res)
      {
        echo '<script type="text/javascript">';
        echo 'alert("Product Blocked")';
        echo '</script>';
        echo "<script>setTimeout(\"location.href = '/pr/Admin/blockpro/product.php';\",10);</script>";
      }
     
    
           
    
    
   
     }
    
    }

// echo 0;
// exit;
?>