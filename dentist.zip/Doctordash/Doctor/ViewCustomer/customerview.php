<html>
<head>
<link rel="stylesheet" href="/pr/Admin/ViewCustomer/css/customerview.css">
<nav id="nav-menu-container">
        <ul class="nav-menu">
          

        </ul>
      </nav>
</head>
<body>
 <table>
 
     <thead>
            <tr>
               <th colspan="6">Registered customer</th>
            </tr>
            <tr style="background-color:#414141e8;">
                <th>Index.</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th></th>
                <th></th>
            </tr>
    </thead>
          <tbody>
                          <?php 
                          include "connection.php";
                          $query="SELECT * FROM `cust_reg`";
                          $result = mysqli_query($db,$query) or die(mysqli_error());
                         if ($result->num_rows > 0)
                          {
                            $i=1;
                            while($row = $result->fetch_assoc()) 
                            {
                           echo "<tr><td>".$i."</td><td>".$row["Name"]."</td><td>".$row["Email"]."</td><td>".$row["Phone"]."</td><td></td></tr>";?>
            
                          <?php
                           ++$i;
                            }
                            
                          }
                          else
                          {
                            echo '<script language="javascript">';
                            echo 'alert("No Registered Users Found")';
                            echo '</script>';
                          }
                          $db->close();
                          ?>
                        </tbody>
                      </table>
<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/pr/customer/js/jquery-3.1.1.min.js"></script>
<script src="/pr/customer/js/js"></script>
<script>

</script>
</body>
</html>
