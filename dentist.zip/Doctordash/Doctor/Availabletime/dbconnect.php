<?php
$con=mysqli_connect("localhost","root","","spark_dental")or die("unable to connect");
?>