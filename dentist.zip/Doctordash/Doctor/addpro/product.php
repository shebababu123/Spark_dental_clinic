<?php



// connect to the database
$dn1= mysqli_connect('localhost', 'root', '','farmers_portal');
if(isset($_POST['submit']))
{   $sub_cat=$_POST['subcategory'];
    $product =$_POST['product'];
    $sq="INSERT INTO `product` ( `Pid`,`Subcat_id`, `pro_name` ,`status` ) VALUES (NULL, '$sub_cat', '$product' ,1)";
    $ch=mysqli_query($dn1,$sq);
   
    if($ch)
    {
        echo" <script>
          alert('PRODUCT ADDED SUCCESSFULLY');
          </script>";
         echo "<script>setTimeout(\"location.href = '/pr/admin/addpro/addpro.php';\",100);</script>";
    }
    else
    {
        echo" <script>
        alert('PRODUCT ALREADY EXIST');
        </script>";
        echo "<script>setTimeout(\"location.href = '/pr/admin/addpro/addpro.php';\",100);</script>";
    }
    
}

mysqli_close($dn1);
?>

