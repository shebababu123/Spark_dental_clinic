$(document).ready(function(){
    //reject
    $('.reject').click(function(){
     
      var el = this;
      var regid = this.id;
      // AJAX Request
      $.ajax({
      url: "/printer/Admin/student/remove.php",
      type: "POST",
      data: {id : regid},
      success: function(response){
    if(response == 1){
    // Remove row from HTML Table
    $(el).closest('tr').css('background','tomato');
    $(el).closest('tr').fadeOut(800,function(){
    $(this).remove();
    });
    }else{
    alert('Invalid ID.');
    }
    }
    });
    
    });

    $('.accept').click(function(){
        var el = this;
        var regid = this.id;
     // AJAX Request
     $.ajax({
        url: "/printer/Admin/student/add.php",
        type: "POST",
        data: {id : regid},
        success: function(response){
      if(response == 1){
      // Remove row from HTML Table
      $(el).closest('tr').css('background','SpringGreen');
      $(el).closest('tr').fadeOut(800,function(){
      $(this).remove();
      });
      }else{
      alert('Invalid ID.');
      }
      }
      });
    });
    });