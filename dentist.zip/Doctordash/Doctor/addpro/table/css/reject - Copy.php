<?php 
$db = mysqli_connect('localhost', 'root', '', 'fresh_gro') or die ("Error connecting to Database".$db->connect_error);
  $id = $_GET['id'];
 
 if(isset($id))
  {
  
  // Check record exists
  $query = "SELECT * FROM `attendance` WHERE leave_id='$id'";
   $result = mysqli_query($db,$query);

  if ($result->num_rows > 0)
  {
     // Delete record
    $del = "DELETE FROM `attendance` WHERE leave_id='$id'";
    $res=mysqli_query($db,$del);
    if($res)
    {
    
        echo '<script type="text/javascript">';
        echo 'alert("Request Rejected")';
        echo '</script>';
        echo "<script>setTimeout(\"location.href = '/fresh_gro1/admin/leave approval/table/leaveapproval.php';\",200);</script>";
    
    }
   
     }
    }

// echo 0;
// exit;
?>