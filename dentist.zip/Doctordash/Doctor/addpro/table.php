<html>
<head>
<link href="/pr/addpro/css/table.css" rel="stylesheet">
</head>
<body>
<?php 

$id = $_POST["id"];

?>
<table class="rwd-table">
          <tr>
               <th>Existing Products</th>
        </tr>
         
         <?php 
    include "connection.php";
    $query="SELECT * FROM `add_product` where cat_id='$id'";
    $result = mysqli_query($db,$query) or die(mysqli_error());
    if ($result->num_rows > 0)
    {
                          
    while($row = $result->fetch_assoc()) 
    {
      
     ?><tr><td data-th="Movie Title"><?php echo $row["pro_name"]; ?></td> </tr> 

    <?php } } ?>
        
       </table>
</body>
</html>