<?php  
   $cid=$_POST["id"];
 
  if(isset($cid))
  {
    include "connection.php";
    $query="SELECT * FROM `add_product` WHERE Cid='$cid'";
    $result = mysqli_query($db,$query) or die(mysqli_error());
    if ($result->num_rows > 0)
    {
                          
    while($row = $result->fetch_assoc()) 
    {
      
     echo'<tr><td data-th="Movie Title">';
     echo $row["pro_name"];
     echo'</td></tr>';
    }
  }
    else
    {
      echo'<tr><td data-th="Movie Title">';
     echo "No products in this category";
     echo'</td></tr>';  
    }
  }
    

   ?>