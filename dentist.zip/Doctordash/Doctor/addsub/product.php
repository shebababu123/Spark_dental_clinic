<?php



// connect to the database
$dn= mysqli_connect('localhost', 'root', '','farmers_portal');
if(isset($_POST['submit']))
{   $cat=$_POST['category'];
    $product = $_POST['subcat'];
    $sq="INSERT INTO `add_subcategory` (`Subcat_id`, `cid`, `Subcat_name`) VALUES (NULL, '$cat', '$product')";
    $ch=mysqli_query($dn,$sq);
   
    if($ch)
    {
        echo" <script>
          alert('PRODUCT ADDED SUCCESSFULLY');
          </script>";
         echo "<script>setTimeout(\"location.href = '/pr/admin/addsub/addsub.php';\",100);</script>";
    }
    else
    {
        echo" <script>
        alert('PRODUCT ALREADY EXIST');
        </script>";
       echo "<script>setTimeout(\"location.href = '/pr/admin/addsub/addsub.php';\",100);</script>";
    }
    
}

mysqli_close($dn);
?>

