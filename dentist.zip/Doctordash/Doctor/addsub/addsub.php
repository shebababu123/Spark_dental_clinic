
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Add Subcategory</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Roboto:100,300,400,500,700|Philosopher:400,400i,700,700i" rel="stylesheet">

  <!-- Bootstrap css -->
  <!-- <link rel="stylesheet" href="css/bootstrap.css"> -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.theme.default.min.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/modal-video/css/modal-video.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/table.css" rel="stylesheet">
<style>
@import url(https://fonts.googleapis.com/css?family=Roboto:300);


.form {
  width: 360px;
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 360px;
  margin: 60px auto 100px;
  padding: 45px;
  text-align: center;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #FFF;
  width: 100%;
  border-color: #4CAF50;
  border-radius:50px;
  padding: 15px;
  color: #4CAF50;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form button:hover,.form button:active,.form button:focus {
  background: #43A047;
  color: #FFF;
  border-color: #FFF;
  
}

.box {
  
   margin-left: auto;
  
}

.box select {
  background-color: #55be66;
  color: white;
  padding: 12px;
  width: 360px;
  border: none;
  font-size: 20px;
  box-shadow: 0 5px 25px rgba(76, 212, 128, 0.397);
  -webkit-appearance: button;
  appearance: button;
  outline: none;
}

.box::before {
  content: "\f13a";
  font-family: FontAwesome;
  position: absolute;
  top: 0;
  right: 0;
  width: 20%;
  height: 100%;
  text-align: center;
  font-size: 28px;
  line-height: 45px;
  color: rgba(255, 255, 255, 0.5);
  background-color: rgba(255, 255, 255, 0.1);
  pointer-events: none;
}

.box:hover::before {
  color: rgba(255, 255, 255, 0.6);
  background-color: rgba(255, 255, 255, 0.2);
}

.box select option {
  padding: 30px;
}
</style>
 
    <script>
    function validate(e)
{
    var sel = document.getElementById("cat").value;
    var pro=document.getElementById("product").value;
    if(sel == "")
    {

alert("Specify a Subcategory");
document.getElementById("cat").focus();
return false;
}
    if(pro == "")
    {

    alert("Specify a Subcategory name");
    document.getElementById("product").focus();
    return false;
    }
}
</script>
</head>


<body>

  <header id="header" class="header header-hide" style="background-color:green;">
    <div class="container">

      <div id="logo" class="pull-left">
        <!--<h1><a href="#body" class="scrollto"><span></span>ADD PRODUCT</a></h1>
         Uncomment below if you prefer to use an image logo -->
        <!-- <a href="#body"><img src="img/logo.png" alt="" title="" /></a>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          

        </ul>
      </nav>

    </div>
  </header><!-- #header -->

  
  <section id="get-started" class="padd-section text-center wow fadeInUp">

<center><div class="container">
  <div id="tbl_block">
  <table class="rwd-table" id="protable">
  <thead>
          <tr>
               <th>Existing Subcategory</th>
        </tr>
  </thead>
  <tbody id="result">
  
  </tbody>
 
  
    </div>
</div>
</center>

      <div class="login-page">
          <div class="form">
            <form class="login-form" action="product.php" method="POST">
              <div class="box">
                <select name="category" id="cat">
                  <option value="" selected>Select Category</option>
                  <?php
                   $db = mysqli_connect('localhost', 'root', '', 'farmers_portal') or die ("Error connecting to Database".$db->connect_error);
                    $query="SELECT * FROM `add_category`";
                    $result = mysqli_query($db,$query) or die(mysqli_error());
                    if ($result->num_rows > 0)
                    {
                     while($row = $result->fetch_assoc()) 
                    {
                      echo '<option value="'.$row["cid"].'">'.$row["catname"].'</option>';
                    }
                  }
                    ?>
                 
                </select>
              
            </div>
            <br>
                <input type="text" name="subcat"  autocomplete="off" id="product" placeholder="Enter Subcategory Name"/>
                <br>
                <br>
                <button type="submit" name="submit" onclick="return validate(this)">ADD SUBCATEGORY</button>
            </form>
           </div>
         </div>
         </div>
       </div>
     </div>
</div>
</div>
</center>

  

        
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- JavaScript Libraries -->
  <script src="js/jquery-3.1.1.min.js"></script>
  <script src='http://code.jquery.com/jquery-latest.js'></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/modal-video/js/modal-video.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="addc/contactform/contactform.js"></script>
  <script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
  <!-- Template Main Javascript File -->
  <script src="/pr/Admin/addpro/js/jquery-3.1.1.min.js"></script>

  <script>
  $(document).ready(function(){
    $("#cat").change(function(e) {
    var a=$('#cat option:selected').attr('value');
    // alert(a);

     $.ajax({
        url: "/pr/Admin/addsub/load.php",
        type: "POST",
        data: {id : a},
        success: function(response){
      if(response){
        $("#result").html(response);
      }else{
      alert('Invalid ID.');
      }
      }
      });


        });
  });
 
</script>
  

</body>
</html>


