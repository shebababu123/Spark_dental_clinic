function validate(e)
{

    var category=document.getElementById("category").value;
   
    if(category == "")
    {

    swal("OOps!", "Specify category", "warning");
    document.getElementById("category").focus();
    return false;
    }
}