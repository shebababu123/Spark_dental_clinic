$( document ).ready(function() {
    $("#forgotform").hide();
    $('#forgot').click(function(){
    //alert("hi");
    $("#forgotform").show();
    $('#lgform').hide();
    });


    $('#bklogin').click(function(){
        //alert("hi");
        $("#forgotform").hide();
        $('#lgform').show();
        });


    $('#btn_reset').click(function(){
        var email =$('#foremail').val();
        //alert (email);
        $.ajax({
       url:"forgot.php",
       type:"POST",
       data:{ sheba : email1 },
       success: function(response){
        alert (response);
       }
        });


    });





});

function validate(e)
{
   
    var email=document.getElementById("email").value;
    var password=document.getElementById("password").value;
   
    if(email == "")
    {

    swal("OOps!", "Specify Email", "warning");
    document.getElementById("email").focus();
    return false;
    }
   
    if(password=="")
    {
    swal("OOps!", "Specify Password", "warning");
    document.getElementById("password").focus();
    return false;
    }
    else if(password.length<8)
    {
        swal("OOps!", "Password should be minimum 8 charecters long ", "warning");
        document.getElementById("password").focus();
        return false;
    }
    


}