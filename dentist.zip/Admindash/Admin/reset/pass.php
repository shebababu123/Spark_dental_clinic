<?php  
session_start();
//$username=$_SESSION['Role'];
$username="admin";
$db = mysqli_connect('localhost', 'root', '', 'farmers_portal') or die ("Error connecting to Database".$db->connect_error);
$oldpass=$_POST['oldpsw'];
$newpass=$_POST['newpassword'];
$oldpassen=md5($oldpass);
$newpassen=md5($newpass);


if(isset($oldpass)&&isset($newpass))
{
    $query="SELECT * FROM `login` WHERE User_name ='$username' AND Password='$oldpassen'";
    $result = mysqli_query($db,$query);
    if ($result->num_rows > 0)
    {
        $qr="UPDATE `login` SET Password='$newpassen' WHERE user_name ='$username'";
        $rst=mysqli_query($db,$qr);
        if($rst)
        {
                echo '<script type="text/javascript">';
                echo 'alert("Password Changed")';
                echo '</script>';
                echo "<script>setTimeout(\"location.href = '/pr/Admin/admin.php';\",0);</script>";
        }
    }




}
else
{
    echo 0;
    exit;
}


echo 0;
 exit;
?>