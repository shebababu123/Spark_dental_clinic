
<html>
<head>
<link rel="stylesheet" href="\DentalClinicManagement\dentist\Admindash\Admin\viewdoctor\css\customerview.css">
<nav id="nav-menu-container">
        <ul class="nav-menu">
          

        </ul>
      </nav>
</head>
<body>
 <table>
 
     <thead>
            <tr>
               <th colspan="8" style="font-size:35px;color:black;">Registered Doctors</th>
            </tr>
            <tr style="background-color:black; color:white;">
                <th>Index.</th>
                <th>Fullname</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Specialization</th>
                <th>Qualification</th>
                <th>Phone</th>
                <th>Email</th>
                
            </tr>
    </thead>
          <tbody>
                          <?php 
                          include "dbconnect.php";
                          $query="select * from tbl_adddoctor";
                          $result = mysqli_query($con,$query) or die(mysqli_error());
                         if ($result->num_rows > 0)
                          {
                            $i=1;
                            while($row = $result->fetch_assoc()) 
                            {
                                $id=['Doctor_id'];
                                $name=$row['D_name'];
                                $gen=$row['D_gender'];
                                $add=$row['D_address'];
                                $sp=$row['D_specialization'];
                                $qul=$row['D_qualification'];
                                $ph=$row['D_phone'];
                                $lo=$row['Login_id'];
                                $q="select * from tbl_login where Login_id=$lo";
                                $s=mysqli_query($con,$q);
                                while ($r4=mysqli_fetch_array($s)) {
                                  $em=$r4['L_email'];

                                $q2="select * from tbl_specialization where Spec_id=$sp";
                                $s2=mysqli_query($con,$q2);
                                while ($r2=mysqli_fetch_array($s2)) {
                                $spe=$r2['Specialization'];

                                $q3="select * from tbl_quali where Quali_id=$qul";
                                $s3=mysqli_query($con,$q3);
                                while ($r3=mysqli_fetch_array($s3)) {
                                $qua=$r3['Qualifications'];
                           echo "<tr style='color:black;'><td>".$i."</td><td>$name</td><td>$gen</td><td>$add</td><td>$spe</td><td>$qua</td><td>$ph</td><td>$em</td></tr>";?>
                           <!-- <td>
                            <a href="update.php?id=<?php echo $id;?>" ><button class="Edit">Edit</button></a>
                            </td>
                            </tr>-->
                          <?php
                           ++$i;
                            }
                          }
                        }
                      }
                            
                          }
                          else
                          {
                            echo '<script language="javascript">';
                            echo 'alert("No Registered Patients Found")';
                            echo '</script>';
                          }
                          $con->close();
                          ?>
                        </tbody>
                      </table>
<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/pr/customer/js/jquery-3.1.1.min.js"></script>
<script src="/pr/customer/js/js"></script>
<script>

</script>
</body>
</html>
