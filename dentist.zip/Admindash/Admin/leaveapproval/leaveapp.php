<html>
<head>
<link rel="stylesheet" href="\DentalClinicManagement\dentist\Admindash\Admin\leaveapproval\css\leaveapproval.css">

</head>
<body>
 <table>
 
     <thead>
            <tr>
               <th colspan="6">Leave Requests</th>
               <th></th>
            </tr>
            <tr style="background-color:#414141e8;">
                <th>Index.</th>
                <th>Name</th>
                <th>Date</th>
                <th>Reason</th>
                <th colspan="5" style="text-align:left;">Action</th>
            </tr>
    </thead>
    <tbody>
                         
                          <?php 
                          include "dbconnect.php";
                          $query="SELECT a.D_name,b.Doctor_id,b.Leavetype_id,b.Date,b.Reason,b.Leave_id,b.Status FROM tbl_adddoctor a JOIN tbl_leave b ON a.Doctor_id=b.Doctor_id AND b.Status='0'";
                          $result = mysqli_query($con,$query);
                         if ($result)
                          {
                            $i=1;
                            while($row = $result->fetch_assoc()) 
                            {
                              
                              if ($row->num_rows > 0)
                               {

                                 
                              echo "<tr><td>".$i."</td><td>".$row["D_name"]."</td><td>".$row["Date"]."</td><td>".$row["Reason"]."</td>";?>
                           <td>
                          <a href="/DentalClinicManagement/dentist/Admindash/Admin/leaveapproval/accept.php?id=<?php echo $row["Leave_id"]; ?>" ><button class="Edit">Approve</button></a>
                          <a href="/DentalClinicManagement/dentist/Admindash/Admin/leaveapproval/reject.php?id=<?php echo $row["Leave_id"]; ?>" ><button class="Block">Reject</button></a>
                          </td></tr>
                          <?php
                                 }
                                }
                           ++$i;
                            }
                            
                          
                        
                          $con->close();
                          ?>
                      </tbody>
                      </table>



<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/printer/Admin/student/js/jquery-3.1.1.min.js"></script>
<script src="js/leaveapproval.js"></script>
<script>

</script>
</body>
</html>
