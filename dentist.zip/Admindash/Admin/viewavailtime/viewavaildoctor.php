
<html>
<head>
<link rel="stylesheet" href="\DentalClinicManagement\dentist\Admindash\Admin\viewavailtime\css\customerview.css">
<nav id="nav-menu-container">
        <ul class="nav-menu">
          

        </ul>
      </nav>
</head>
<body>
 <table>
 
     <thead>
            <tr>
               <th colspan="8" style="font-size:35px;color:black;">Available time for Doctors</th>
            </tr>
            <tr style="background-color:black; color:white;">
                <th>Index.</th>
                <th>Doctorname</th>
                <th>Month</th>
                <th>Dates</th>
                <th>Time</th>
               <th>action</th>
            </tr>
    </thead>
          <tbody>
                          <?php 
                          include "dbconnect.php";
                          $query="SELECT a.Doctor_id,a.Month,a.Date,a.Timeofavailable,b.D_name from tbl_doctoravail a JOIN tbl_adddoctor b ON a.Doctor_id=b.Doctor_id ";
                          $result = mysqli_query($con,$query) or die(mysqli_error());
                         if ($result->num_rows > 0)
                          {
                            $i=1;
                            while($row = $result->fetch_assoc()) 
                            {
                               
                           echo "<tr style='color:black;'><td>".$i."</td><td>".$row["D_name"]."</td><td>".$row["Month"]."</td><td>".$row["Date"]."</td><td>".$row["Timeofavailable"]."</td>";?>
                          <td>
                          <a href="schedule.php?id=<?php echo $row["Doctor_id"]; ?>" ><button class="sche">Schedule</button></a>
                           </td>
                           </tr>
            
                          <?php
                           ++$i;
                            }
                          }
                        
                            
                          else
                          {
                            echo '<script language="javascript">';
                            echo 'alert("No records Found")';
                            echo '</script>';
                          }
                          $con->close();
                          ?>
                        </tbody>
                      </table>
<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/pr/customer/js/jquery-3.1.1.min.js"></script>
<script src="/pr/customer/js/js"></script>
<script>

</script>
</body>
</html>
