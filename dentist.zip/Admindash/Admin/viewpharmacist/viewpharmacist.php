<html>
<head>
<link rel="stylesheet" href="\DentalClinicManagement\dentist\Admindash\Admin\viewpharmacist\css\customerview.css">
<nav id="nav-menu-container">
        <ul class="nav-menu">
          

        </ul>
      </nav>
</head>
<body>
 <table>
 
     <thead>
            <tr>
               <th colspan="6" style="font-size:35px;color:black;">Registered Pharmacist</th>
            </tr>
            <tr style="background-color:black; color:white;">
                <th>Index.</th>
                <th>Fullname</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Email</th>
            </tr>
    </thead>
          <tbody>
                          <?php 
                          include "dbconnect.php";
                          $query="select * from tbl_addpharmacist";
                          $result = mysqli_query($con,$query) or die(mysqli_error());
                         if ($result->num_rows > 0)
                          {
                            $i=1;
                            while($row = $result->fetch_assoc()) 
                            {
                                $name=$row['Ph_name'];
                                $gen=$row['Ph_gender'];
                                $add=$row['Ph_address'];
                                $ph=$row['Ph_phone'];
                                $id1=$row['Login_id'];
                                $q2="select * from tbl_login where Login_id=$id1";
                                $s2=mysqli_query($con,$q2);
                                while ($r2=mysqli_fetch_array($s2)) {
                                $id2=$r2['L_email'];
                           echo "<tr style='color:black;'><td>".$i."</td><td>$name</td><td>$gen</td><td>$add</td><td>$ph</td><td>$id2</td></tr>";?>
            
                          <?php
                           ++$i;
                            }
                        }
                            
                          }
                          else
                          {
                            echo '<script language="javascript">';
                            echo 'alert("No Registered Pharmacists Found")';
                            echo '</script>';
                          }
                          $con->close();
                          ?>
                        </tbody>
                      </table>
<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/pr/customer/js/jquery-3.1.1.min.js"></script>
<script src="/pr/customer/js/js"></script>
<script>

</script>
</body>
</html>
