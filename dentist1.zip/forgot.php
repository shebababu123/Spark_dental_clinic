<?php
include 'dbconnect.php';
$Generator = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
$j = substr(str_shuffle($Generator),0,10);

	if (isset($_POST['submit'])) {

		$email=$_POST['email'];
		$pass=md5($j);
      
        $sql="select * from tbl_login where L_email='$email'";
            $result=mysqli_query($con,$sql);
            $rowcount=mysqli_num_rows($result);
            if($rowcount!=0){
		$q="update tbl_login set L_password='$pass' where L_email='$email'";
		$ch=mysqli_query($con,$q);
        if($ch)
        {
           
            ?>
   				<script>
 				alert("Password is changed");
				window.location="/DentalClinicManagement/dentist/index.php";
				</script>
					<?php
                $result="";
                    $maild='sparkdental2020@gmail.com';
                    require 'phpmailer/PHPMailerAutoload.php'; 
                    $mail = new PHPMailer(true);

                    $mail->isSMTP();// Set mailer to use SMTP
                    $mail->CharSet = "utf-8";// set charset to utf8
                    $mail->SMTPAuth = true;// Enable SMTP authentication
                    $mail->SMTPSecure = 'tls';// Enable TLS encryption, `ssl` also accepted

                    $mail->Host = 'smtp.gmail.com';// Specify main and backup SMTP servers
                    $mail->Port = 587;// TCP port to connect to
                    $mail->SMTPOptions = array(
                                     'ssl' => array(
                                     'verify_peer' => false,
                                        'verify_peer_name' => false,
                                    'allow_self_signed' => true
                                     )
                                );
                $mail->isHTML(true);// Set email format to HTML
                $mail->Username='sparkdental2020@gmail.com';//send cheyyunna mail id
                $mail->Password='spark2020dental#';//ayinte password

                $mail->setFrom($maild,'Spark Dental Clinic');
                $mail->addAddress($email);//receiverinte mail
                $mail->addReplyTo($maild);//thirich reply theranam engil a mail

                $mail->isHTML(true);//html code mail ayakkan true akki iduka
                $mail->Subject='Confirmation MAil';//mail subject
                $mail->Body='Hello your new password for your account is <b>'.$j.'</b>';//body


                $mail->send();
                if(!$mail->send())
                {
                    $result="Something went wrong";
                   echo $result;

                }
                else
                {
                    $result="Something went successfully";
                   echo  $result;
                }

        }
    
	    else
		{
  		    echo"error:".$sql."<br>".mysqli_error($con);
		}
}
    }
				mysqli_close($con);
				?>