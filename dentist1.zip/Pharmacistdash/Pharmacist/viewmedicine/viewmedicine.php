<html>
<head>
<link rel="stylesheet" href="\DentalClinicManagement\dentist\Pharmacistdash\Pharmacist\viewmedicine\css\customerview.css">
<nav id="nav-menu-container">
        <ul class="nav-menu">
          

        </ul>
      </nav>
</head>
<body>
 <table>
 
     <thead>
            <tr>
               <th colspan="10" style="font-size:35px;color:black;">Medicines</th>
            </tr>
            <tr style="background-color:black; color:white;">
                <th>Index.</th>
                <th>Medicine</th>
                <th>Category</th>
                <th>Desciption</th>
                <th>Company</th>
                <th>Date</th>
                <th>Quantity</th>
                <th>Status</th>
                <th>Unit cost</th>
                <th>Action</th>
                
               
            </tr>
    </thead>
          <tbody>
                          <?php 
                          include "dbconnect.php";
                          $query="SELECT * FROM `addmedicine`";
                          $result = mysqli_query($con,$query) or die(mysqli_error());
                         if ($result->num_rows > 0)
                          {
                            $i=1;
                            while($row = $result->fetch_assoc()) 
                            {
                              echo "<tr>";
                              ?> 
                              <form action="stockupdate.php" method="POST">
                                <input type="hidden" name="mediid" value="<?php echo $row["Medi_id"]; ?>">
                              <?php
                           echo "<tr style='color:black;'><td>".$i."</td><td>".$row["Medicine"]."</td><td>".$row["Category"]."</td><td>".$row["Description"]."</td><td>".$row["Company"]."</td><td>".$row["Date_supplied"]."</td>";?>
                            <td>
                            <input style="width : 50px;" type="text" name="stock" class="stock" value="<?php echo $row["Quantity"]; ?>"><td>
                            
                            <?php
                                if($row["Status"]=="0")
                                {
                                  echo "Blocked";
                                } 
                                elseif($row["Status"]=="1")
                                {
                                  echo "In Stock";
                                }
                                else if($row["Status"]=="2")
                                {
                                  echo "Expired";
                                }
                                else
                                {
                                  echo "Out of Stock";
                                }?>
                            </td></td>
                            <td><?php echo $row["Cost"];?></td>
                            <td>

                            <a href="?id=<?php echo $row["Medi_id"]; ?>" ><button class="Edit" type="submit" name="submit">Update</button></a>

                            </form>
                            </td>
                             <td></td>
                            
                          <?php
                           ++$i;
                            }
                        }
                            
                          
                          else
                          {
                            echo '<script language="javascript">';
                            echo 'alert("No medicines Found")';
                            echo '</script>';
                          }
                          $con->close();
                          ?>
                        </tbody>
                      </table>
<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/pr/customer/js/jquery-3.1.1.min.js"></script>
<script src="/pr/customer/js/js"></script>
<script>

</script>
</body>
</html>
