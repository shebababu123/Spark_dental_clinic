<?php 
 include 'dbconnect.php';
  $id = $_GET['id'];
 
 if(isset($id))
  {
  
  // Check record exists
  $query = "SELECT * FROM `addmedicine` WHERE Medi_id='$id'";
   $result = mysqli_query($con,$query);

  if ($result->num_rows > 0)
  {
     // update status
    $del = "UPDATE addmedi SET status=1 WHERE Leave_id= '$id'";
    $res=mysqli_query($con,$del);
    
     if($res)
     {
     
        
        echo '<script type="text/javascript">';
        echo 'alert("Request Accepted")';
        echo '</script>';
        echo "<script>setTimeout(\"location.href = '/DentalClinicManagement/dentist/Admindash/Admin/leaveapproval/leaveapp.php';\",200);</script>";
      
     }
           
   
     }
    }

?>