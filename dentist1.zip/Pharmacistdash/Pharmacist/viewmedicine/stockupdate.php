<?php 
 include 'dbconnect.php';
  $id = $_POST["Medi_id"];
  $stock = $_POST["stock"];
 if(isset($_POST["submit"]))
  {
  
  // Check record exists
  $query = "UPDATE `addmedicine` SET Quantity='$stock',Status=1 WHERE pid='$id'";
   $result = mysqli_query($con,$query);

  if ($result)
  {
   
        
        echo '<script type="text/javascript">';
        echo 'alert("Stock Updated")';
        echo '</script>';
        echo "<script>setTimeout(\"location.href = '/DentalClinicManagement/dentist/Pharmacistdash/Pharmacist/viewmedicine/viewmedicine.php';\",0);</script>";
    
           
   
     }
    }

?>