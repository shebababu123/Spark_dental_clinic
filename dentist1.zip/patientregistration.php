	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Spark Dental Care</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/jquery-ui.css">			
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
			<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'>
        </script>
	<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
	<script src="validate.js"></script>
	<style type="text/css">
		.error{
  color: #F00;
  background-color: #FFF;
		}
		.form1{
			margin-left: 20px;

		}

	</style>
	 
		</head>
		<body>	
			  <header id="header" id="home">
		  		<div class="header-top">
		  			<div class="container">
				  		<div class="row align-items-center">
				  			<div class="col-lg-6 col-sm-6 col-4 header-top-left no-padding">
				        		<a href="index.php"><img src="img/logo1.png" alt="" title="" /></a>			
				  			</div>
				  			<div class="col-lg-6 col-sm-6 col-8 header-top-right no-padding">
								<a class="btns" href="tel:+91 8113843635">+91 8113843635</a>
				  				<a class="btns" href="mailto:sparkdental@gmail.com">spardental@gmail.com</a>		
				  				<a class="icons" href="tel:+91 8113843635">
				  					<span class="lnr lnr-phone-handset"></span>
				  				</a>
				  				<a class="icons" href="mailto:sparkdental2020@gmail.com">
				  					<span class="lnr lnr-envelope"></span>
				  				</a>		
				  			</div>
				  		</div>			  					
		  			</div>
				</div>
			    <div class="container main-menu">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="index.php">Home</a></li>
				          <li><a href="about.html">About</a></li>
				          <li><a href="services.html">Services</a></li>
				          <li><a href="opening-hour.html">Opening Hour </a></li>
				          <li class="menu-has-children"><a href="">Blog</a>
				            <ul>
				              <li><a href="blog-home.html">Blog Home</a></li>
				              <li><a href="blog-single.html">Blog Single</a></li>				              
				            </ul>
				          </li>	
				         			          	           				          	          
				          <li><a href="contact.html">Contact</a></li>
				           <li><a href="Signin.php">Sign In</a></li>
				        </ul>
				      </nav><!-- #nav-menu-container -->
			      	<div class="menu-social-icons">
						<a href="#"><i class="fa fa-facebook"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-dribbble"></i></a>
						<a href="#"><i class="fa fa-behance"></i></a>
					</div>	    		
			    	</div>
			    </div>
			  </header><!-- #header -->
			  
			<!-- start banner Area -->
			<section class="banner-area relative about-banner" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Patient Registration		
							</h1>	
							<p class="text-white link-nav"><a href="index.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="patientregistration.php"> Patient Signup</a></p>
						</div>	
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

			<!-- Start Sample Area -->
			<section class="reg">
				<div class="container"><br><br><br>
							<div class="sign"><h2 style="color:black; padding-left: 360px;">Patient Signup</h2></div>
       					 <div class="row no-gutters1 slider-text justify-content-center align-items-center">
       					 <div class="col-lg-8 col-md-10 mt-0 mt-md-5 d-flex">

						<center><form action="" method="post" name="form1" id="reg" class="" autocomplete="off" style="background:#002366;padding-top: 30px;padding-left: 20px;padding-bottom: 30px; width:600px; height: 700px;font-family: Georgia ;">
						
	    				<div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label"style="padding-right: 80px; padding-left: 70px;color: white;font-size: 20px;">First Name: </label>
							</div>
							<div class="form-group ml-2">
	    					<input type="text" name="fname" class="form-control" placeholder="First name" required>
							</div>
	    				</div>
	    				<div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label" style="padding-right: 80px; padding-left: 70px;color: white;font-size: 20px;">Last Name: </label>
							</div>
							<div class="form-group ml-2">
	    					<input type="text" name="lname" class="form-control" placeholder="Last name" required>
							</div>
	    				</div>
	    				<div class="d-flex">
	    					<div class="form-group mr-2">
	    					<label for="" class="label" style="padding-right: 110px; padding-left: 70px; color: white;font-size: 20px;">Gender: </label></br>
							</div>
							<div class="form-group ml-2">
	    					<input type="radio" name="gender" value="Male" style="width:40px;height: 20px;"><font size="4.5px" color="white">Male</font>                             
							<input type="radio" name="gender" value="Female"style=" width:40px;height: 20px;"><font size="4.5px" color="white">Female</font>
							</div>
						</div>
						<div class="d-flex">
	    					<div class="form-group mr-2">
	                		<label for="" class="label" style="padding-right: 130px; padding-left: 70px;color: white;font-size: 20px;">DOB: </label>
							</div>
							<div class="form-group ml-2">
	                		<input type="date" name="dob" class="form-control" placeholder="Date of Birth" style="width: 220px;" required>
							</div>
	              		</div>
						<div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label" style="padding-right: 60px; padding-left: 70px;color: white;font-size: 20px;">Blood Group:</label>
							</div>
							<div class="form-group ml-2">
		                    <select name="blood" id="dist" class="form-control" style="width: 220px;">
		                      	<option value="">Select Bloodgroup</option>
								<?php 
								include 'dbconnect.php'; 
								$q1="select * from tbl_bloodgroup";
								$ch1=mysqli_query($con,$q1);
								while($data=mysqli_fetch_array($ch1))
								{
								$d1=$data["Blood_id"];
								echo "<option value=$d1>"; echo $data["Bloodgroup"]; } echo "</option>";
								?>
		                    </select>
							</div>
		                </div>
						<div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label" style="padding-right: 100px; padding-left: 70px;color: white;font-size: 20px;">Address: </label>
							</div>
							<div class="form-group ml-2">
	    					<input type="text" name="address" class="form-control" placeholder="Address" required>
							</div>
						</div>
						<div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label" style="padding-right: 115px; padding-left: 70px;color: white;font-size: 20px;">Phone: </label>
							</div>
							<div class="form-group ml-2">
	    					<input type="text" name="phone" class="form-control" placeholder="Phoneno" required > 
							</div>
	    				</div>
						<div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label" style="padding-right: 95px; padding-left: 70px;color: white;font-size: 20px;">Email-Id: </label>
							</div>
							<div class="form-group ml-2">
	    					<input type="email" name="email" class="form-control" placeholder="Email-id" required>
							</div>
	    				</div>
						
	            		<div class="group" align="center">
	              			<input type="submit" name="submit" align="middle" value="Submit" style="font-size: 16px; background: #DE006F;width: 170px;" class="btn btn-primary py-3 px-4">
	            		</div>
   				</form>
   			</center>
							
						</div>
					</div>
				</div>
				<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
    jQuery.validator.addMethod("noSpace", function(value, element) { 
    return value == '' || value.trim().length != 0;  
}, "No space please and don't leave it empty");
jQuery.validator.addMethod("phonenum", function(value, element) { 
    return this.optional( element ) || /^([7-9_\.\-])+(([0-9]))+$/.test( value ); 
}, "Please enter valid phone number");
jQuery.validator.addMethod("customEmail", function(value, element) { 
  return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.))+([a-zA-Z0-9]{2,4})+$/.test( value ); 
}, "Please enter valid email address!");

$.validator.addMethod("alphabetsnspace", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    });


$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, numbers, and underscores only please" );
var $ureg = $('#reg');
if($ureg.length){
  $ureg.validate({
      rules:{
          //username is the name of the textbox
          fname: {
              required: true,
              alphabetsnspace: true,
			  maxlength:15
              //alphanumeric is the custom method, we defined in the above
              
          },
		  lname: {
              required: true,
              alphabetsnspace: true,
			  maxlength:15
              //alphanumeric is the custom method, we defined in the above
              
          },
		  dob:{
              required: true,
              
            },
			blood:{
                required: true
                },
          address:{
                required: true
                },
				
           phone:{
              required: true,
              number: true,
              minlength: 10,
              maxlength: 10,
			  phonenum:true
            },
          email: {
              required: true,
              customEmail: true
          }
        
          
         
         
      },
      messages:{
          fname: {
              //error message for the required field
              required: 'Please enter firstname!',
              alphabetsnspace: 'only alphabets and space allowed'
          },
		  lname: {
              //error message for the required field
              required: 'Please enter lastname!',
              alphabetsnspace: 'only alphabets and space allowed'
          },
		   dob: {
              required: 'Please enter date of birth!'
          },
		   blood: {
              required: 'Please enter bloodgroup!'
          },
           address: {
              required: 'Please enter address!'
          },
           
          phone:{
              required: 'Mandatory field',
              number: 'Please enter only numbers',
              minlength: 'Please enter 10 digits',
			  phonenum: 'Please start with 7,8,9'
              
            },
          
          email: {
              required: 'Please enter email!',
              //error message for the email field
              email: 'Please enter valid email!'
          },
         
         
          
          
      },
      
  });
}
  </script>	

<?php 
		include 'dbconnect.php';
			if(isset($_POST['submit']))
			{

				$Generator = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
				$j = substr(str_shuffle($Generator),0,10);
				
			  $fname=$_POST['fname'];
			  $lname=$_POST['lname'];
			$gender=$_POST['gender'];
			$dob=$_POST['dob'];
			$blood=$_POST['blood'];
			$address=$_POST['address'];
			$phone=$_POST['phone'];
			$email=$_POST['email'];

			$pass=md5($j);
			$q="select Login_id from tbl_login where L_email='$email'";
			$r1=mysqli_query($con,$q);
			$re=mysqli_fetch_array($r1,MYSQLI_ASSOC);
			$iid=$re['Login_id'];
			if($iid!="")
			{
			echo"<script>alert('Already exists with this email');</script>";
			}
			else
			{
			$sq="INSERT INTO `tbl_login`(`Login_id`, `L_email`, `L_password`, `L_usertype`, `L_status`) VALUES (NULL,'$email','$pass',1,1)";
			if(mysqli_query($con,$sq))
			{
  				$s=mysqli_query($con,"select Login_id from tbl_login where L_email='$email'");
  				$r=mysqli_fetch_array($s,MYSQLI_ASSOC);
  				$lid=$r['Login_id'];
				
				$sql="INSERT INTO `tbl_patientreg`( `Login_id`, `PF_name`, `PL_Name`, `P_Gender`, `P_DOB`, `P_Bloodid`, `P_Address`, `P_Phone`, `P_Status`) VALUES ('$lid','$fname','$lname','$gender','$dob','$blood','$address','$phone','1')";
 				$ch=mysqli_query($con,$sql);
				if($ch)
				{
  				?>
   				<script>
 				alert("Registered  Successfully");
				window.location="http://localhost/DentalClinicManagement/dentist/Signin.php";
				</script>
					<?php
$result="";
$maild='sparkdental2020@gmail.com';
require 'phpmailer/PHPMailerAutoload.php'; 
$mail = new PHPMailer(true);

$mail->isSMTP();// Set mailer to use SMTP
$mail->CharSet = "utf-8";// set charset to utf8
$mail->SMTPAuth = true;// Enable SMTP authentication
$mail->SMTPSecure = 'tls';// Enable TLS encryption, `ssl` also accepted

$mail->Host = 'smtp.gmail.com';// Specify main and backup SMTP servers
$mail->Port = 587;// TCP port to connect to
$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);
$mail->isHTML(true);// Set email format to HTML
$mail->Username='sparkdental2020@gmail.com';//send cheyyunna mail id
$mail->Password='spark2020dental#';//ayinte password

$mail->setFrom($maild,'Spark Dental Clinic');
$mail->addAddress($email);//receiverinte mail
$mail->addReplyTo($maild);//thirich reply theranam engil a mail

$mail->isHTML(true);//html code mail ayakkan true akki iduka
$mail->Subject='Confirmation MAil';//mail subject
$mail->Body='Hello '.$fname.', password for your account is <b>'.$j.'</b>';//body


$mail->send();
if(!$mail->send())
{
$result="Something went wrong";
echo $result;

}
else
{
    $result="Mail went successfully";  
    echo $result;
}

				}
				else
				{
  				echo"error:".$sql."<br>".mysqli_error($con);
				}
				}
				}
				}
				mysqli_close($con);
				?>
	
	
				
				</session>
			
			<!-- Start Align Area -->
			
			<!-- End Align Area -->

			<!-- start footer Area -->		
			<footer class="footer-area section-gap">
				
					<div class="row footer-bottom d-flex justify-content-between">
						<p class="col-lg-8 col-sm-12 footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
						<div class="col-lg-4 col-sm-12 footer-social">
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-twitter"></i></a>
							<a href="#"><i class="fa fa-dribbble"></i></a>
							<a href="#"><i class="fa fa-behance"></i></a>
						</div>
					</div>
				</div>
			</footer>
			<!-- End footer Area -->

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
 			<script src="js/jquery-ui.js"></script>			
			<script src="js/owl.carousel.min.js"></script>						
			<script src="js/jquery.nice-select.min.js"></script>							
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>