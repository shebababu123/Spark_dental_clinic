function validate(e)
{

    var username=document.getElementById("username").value;
    var password=document.getElementById("password").value;
   
    if(username == "")
    {

    swal("OOps!", "Specify Username", "warning");
    document.getElementById("username").focus();
    return false;
    }
   
    if(password == "")
    {
    swal("OOps!", "Specify Password", "warning");
    document.getElementById("password").focus();
    return false;
    }
    else if(password.length<8)
    {
        swal("OOps!", "Password should be minimum 8 charecters long ", "warning");
        document.getElementById("password").focus();
        return false;
    }
    


}
