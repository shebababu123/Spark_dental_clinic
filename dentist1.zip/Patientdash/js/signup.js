document.querySelector('.img__btn').addEventListener('click', function() {
  document.querySelector('.cont').classList.toggle('s--signup');
});



function namecheck(e)
{
    var name="";
    name= document.getElementById("txt_name").value;
if( name =="")
{
   document.getElementById("txt_name").style.borderColor="red";
   document.getElementById("txt_name").placeholder="Please Enter Name";
   document.getElementById("txt_name").focus;
   return false;
}
else if(isNaN(name))
{}
 else
 {

    document.getElementById("txt_name").style.borderColor="red";
    document.getElementById("txt_name").value="Name Should Be Charecter only";
    document.getElementById("txt_name").focus;
    return false;
 }
}
function namereset(e)
{
   
   document.getElementById("txt_name").style.borderColor="#797D7F";
   document.getElementById("txt_name").value="";
   document.getElementById("txt_name").placeholder="";
   document.getElementById("txt_name").focus;
}
//address validation

function addresscheck(e)
{
var address="";
address=document.getElementById("address").value;
if(address=="")
{
   document.getElementById("address").style.borderColor="red";
   document.getElementById("address").placeholder="Please enter the address";
   document.getElementById("address").focus;
   return false;
}
}
function addressreset(e)
{
   document.getElementById("address").style.borderColor="#797D7F";
  document.getElementById("address").value="";
  document.getElementById("address").focus;
  document.getElementById("address").placeholder="";
}
//phone
function phonecheck(v)
{
   var phonepattern=/^[7-9][0-9]{9}$/;
   var cphone="";
   cphone=document.getElementById("phone").value;
   if(cphone=="")
   {
   document.getElementById("phone").style.borderColor="red";
   document.getElementById("phone").placeholder="Please Enter phone no.";
   document.getElementById("phone").focus;
   return false;
   }
  
   else if (!phonepattern.test(cphone))
   {
      document.getElementById("phone").style.borderColor="red";
      document.getElementById("phone").value="";
      document.getElementById("phone").placeholder="Invalid phone number format";
      alert("Phone number should be a 10 digit number starting from 7,8,9");
      document.getElementById("phone").focus;
   }

}

function phonereset(e)
{
   
   document.getElementById("phone").style.borderColor="#797D7F";
   document.getElementById("phone").placeholder="";
   document.getElementById("phone").value="";
   document.getElementById("phone").placeholder="";
}
// //email
function emailcheck(e)
{
var email="";
var pattern = /^([a-z0-9A-Z_\.\-])+\@(([a-zA-Z\-])+\.)+([a-zA-Z]{2,4})+$/;
email=document.getElementById("txt_email").value;
if(email=="")
{
   document.getElementById("txt_email").style.borderColor="red";
   document.getElementById("txt_email").placeholder="Please enter the Email";
   document.getElementById("txt_email").focus;
   return false;
}
 else if(!pattern.test(email))
{
   document.getElementById("txt_email").style.borderColor="red";
   document.getElementById("txt_email").value="";
   document.getElementById("txt_email").placeholder="Invalid Email format";
   document.getElementById("txt_email").focus;
}
}


function emailreset(e)
{
   document.getElementById("txt_email").placeholder="";
   document.getElementById("txt_email").style.borderColor="#797D7F";
   document.getElementById("txt_email").value="";
}

//adhar
function adharcheck(e)
{
   var phonepattern=/^[0-9]{10}|[0-9]{12}$/;
   var adhar="";
   adhar=document.getElementById("adhar").value;
   if(adhar=="")
   {
      document.getElementById("adhar").style.borderColor="red";
      document.getElementById("adhar").placeholder="Please enter the Adhar Number";
      document.getElementById("adhar").focus;
      return false;
   }
   else if (!phonepattern.test(adhar))
   {
      document.getElementById("adhar").style.borderColor="red";
      document.getElementById("adhar").value="Enter a 12 digit number";
      document.getElementById("adhar").focus;
      return false; 
   }
   else if(adhar.length>0 && adhar.length!=12)
   {
      document.getElementById("adhar").style.borderColor="red";
      document.getElementById("adhar").value="Adhar no.should contain 12 digits ";
      document.getElementById("adhar").focus;
      return false;  
   }
  
}
function adharreset(e)
{
   document.getElementById("adhar").style.borderColor="#797D7F";
   document.getElementById("adhar").value="";
   document.getElementById("adhar").placeholder="";
}



//pasword
function passwrdcheck(e)
{
   var pswd="";
   pswd=document.getElementById("fpassword").value;
   if(pswd=="")
   {
      document.getElementById("fpassword").style.borderColor="red";
      document.getElementById("fpassword").placeholder="Please enter the password";
      document.getElementById("fpassword").focus;
      return false;
   }
   else if(pswd.legth<8)
    {
       alert("Your password should be 8 letters");
       document.getElementById("fpassword").focus();
        return false;
      
      //document.getElementById("fpassword").style.borderColor="red";
      //document.getElementById("fpassword").value="password should contain atleat 8 chracters";
       // document.getElementById("fpassword").focus;
        //return false;
    }
}
function pswdreset(e)
{
   document.getElementById("fpassword").style.borderColor="#797D7F";
   document.getElementById("fpassword").value="";
   document.getElementById("fpassword").placeholder="";

}



function fcpasscheck(e)
{
   var cpswd="";
   pswd=document.getElementById("cpassword").value;
   if(cpswd=="")
   {
      document.getElementById("cpassword").style.borderColor="red";
      document.getElementById("cpassword").placeholder="Please enter the password";
      document.getElementById("cpassword").focus;
      return false;
   }
   else if(cpswd.legth<8)
    {
       alert("Your password should be 8 letters");
       document.getElementById("cpassword").focus();
        return false;
      
    }
}

function checkpsw(e)
{
   name= document.getElementById("txt_name").value;
   if( name =="")
   {
      document.getElementById("txt_name").style.borderColor="red";
      document.getElementById("txt_name").placeholder="Please Enter Name";
      document.getElementById("txt_name").focus;
      return false;
   }

 var address="";
address=document.getElementById("address").value;
if(address=="")
{
   document.getElementById("address").style.borderColor="red";
   document.getElementById("address").placeholder="Please enter the address";
   document.getElementById("address").focus;
   return false;
}


var cphone="";
cphone=document.getElementById("phone").value;
if(cphone=="")
{
document.getElementById("phone").style.borderColor="red";
document.getElementById("phone").placeholder="Please Enter phone no.";
document.getElementById("phone").focus;
return false;
}

email=document.getElementById("txt_email").value;
if(email=="")
{
   document.getElementById("txt_email").style.borderColor="red";
   document.getElementById("txt_email").placeholder="Please enter the Email";
   document.getElementById("txt_email").focus;
   return false;
}

adhar=document.getElementById("adhar").value;
   if(adhar=="")
   {
      document.getElementById("adhar").style.borderColor="red";
      document.getElementById("adhar").placeholder="Please enter the Adhar Number";
      document.getElementById("adhar").focus;
      return false;
   }



   pswd=document.getElementById("fpassword").value;
   cpswd=document.getElementById("cpassword").value;
   if(pswd=="" || cpswd=="")
   {
      alert("Passwords Empty");
      return false;
   }
   else if(pswd != cpswd)
   {
      alert("Passwords does not match");
      return false;
   }
}



function cpswdreset(e)
{
   document.getElementById("cpassword").style.borderColor="#797D7F";
   document.getElementById("cpassword").value="";
   document.getElementById("cpassword").placeholder="";

}
//customer form validation


function cnamecheck(e)
{
    var cname="";
    cname= document.getElementById("txt_curname").value;
if( cname =="")
{
   document.getElementById("txt_curname").style.borderColor="red";
   document.getElementById("txt_curname").placeholder="Please Enter Name";
   document.getElementById("txt_curname").focus;
   return false;
}

}
function cnamereset(e)
{
   document.getElementById("txt_curname").style.borderColor="#797D7F";
   document.getElementById("txt_curname").placeholder="";
   document.getElementById("txt_curname").value="";
 
}

//cusomer address
function caddresscheck(e)
{
  var caddress="";
  caddress=document.getElementById("caddress").value;
  if(caddress=="")
{
   document.getElementById("caddress").style.borderColor="red";
   document.getElementById("caddress").placeholder="Please enter the address";
   document.getElementById("caddress").focus;
   return false;
}
}
function caddressreset(e)
{
   document.getElementById("caddress").style.borderColor="#797D7F";
   document.getElementById("caddress").value="";
   document.getElementById("caddress").placeholder="";
}


//cusomer phone
function cphonecheck(v)
{
   var phonepattern=/^[7-9][0-9]{9}$/;
   var cphone="";
   cphone=document.getElementById("cphone").value;
   if(cphone=="")
   {
   document.getElementById("cphone").style.borderColor="red";
   document.getElementById("cphone").placeholder="Please Enter phone no.";
   document.getElementById("cphone").focus;
   return false;
   }
   else if (!phonepattern.test(cphone))
   {
      document.getElementById("cphone").style.borderColor="red";
      document.getElementById("cphone").value="";
      document.getElementById("cphone").placeholder="Invalid phone number format";
      alert("Phone number should be a 10 digit number starting from 7,8,9");
      document.getElementById("cphone").focus;
   }

}
function cphonereset(e)
{
   
   document.getElementById("cphone").style.borderColor="#797D7F";
   document.getElementById("cphone").placeholder="";
   document.getElementById("cphone").value="";
   
}
//customer email

function cemailcheck(e)
{
   var cemail="";
   var pattern = /^([a-z0-9A-Z_\.\-])+\@(([a-zA-Z\-])+\.)+([a-zA-Z]{2,4})+$/;
  cemail=document.getElementById("cemail").value;
if(cemail=="")
{
   document.getElementById("cemail").style.borderColor="red";
   document.getElementById("cemail").placeholder="Please enter the Email";
   document.getElementById("cemail").focus;
   return false;
}
else if( !pattern.test(cemail))
{
   document.getElementById("cemail").style.borderColor="red";
   document.getElementById("cemail").value="";
   document.getElementById("cemail").placeholder="Invalid Email format";
   document.getElementById("cemail").focus;
}
}
function cemailreset(e)
{
   
   document.getElementById("cemail").style.borderColor="#797D7F";
   document.getElementById("cemail").value="";
   document.getElementById("cemail").placeholder="";
}

//customer password
function cpasswrdcheck(e)
{
   passwordpattern=/^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/;
   var cpass="";
   cpass=document.getElementById("cpass").value;
   if(cpass=="")
   {
      document.getElementById("cpass").style.borderColor="red";
      document.getElementById("cpass").placeholder="Please enter the password";
      document.getElementById("cpass").focus;
      return false;
   }
   else if (!passwordpattern.test(cpass))
   {
      document.getElementById("cpass").style.borderColor="red";
      document.getElementById("cpass").placeholder="Please enter a valid password password";
      document.getElementById("cpass").focus;
      return false;
   }
}
function cpassreset(e)
{
   document.getElementById("cpass").style.borderColor="#797D7F";
   document.getElementById("cpass").value="";
   document.getElementById("cpass").placeholder="";

}
//confirm password
function cfcheck(e)
{
   var cfpass="";
   cfpass=document.getElementById("cfpass").value;
   if(cfpass=="")
   {
      document.getElementById("cfpass").style.borderColor="red";
      document.getElementById("cfpass").placeholder="Please enter the  Confirm password";
      document.getElementById("cfpass").focus;
      return false;
   }
}
function passreset(e)
{
   document.getElementById("cfpass").style.borderColor="#797D7F";
   document.getElementById("cfpass").value="";
   document.getElementById("cfpass").placeholder="";

}

function passcheck(e)
{
   var cname="";
   cname= document.getElementById("txt_curname").value;
if( cname =="")
{
  document.getElementById("txt_curname").style.borderColor="red";
  document.getElementById("txt_curname").placeholder="Please Enter Name";
  document.getElementById("txt_curname").focus;
  return false;
}

var caddress="";
  caddress=document.getElementById("caddress").value;
  if(caddress=="")
{
   document.getElementById("caddress").style.borderColor="red";
   document.getElementById("caddress").placeholder="Please enter the address";
   document.getElementById("caddress").focus;
   return false;
}


var cphone="";
cphone=document.getElementById("cphone").value;
if(cphone=="")
{
document.getElementById("cphone").style.borderColor="red";
document.getElementById("cphone").placeholder="Please Enter phone no.";
document.getElementById("cphone").focus;
return false;
}

var cemail="";
cemail=document.getElementById("cemail").value;
if(cemail=="")
{
   document.getElementById("cemail").style.borderColor="red";
   document.getElementById("cemail").placeholder="Please enter the Email";
   document.getElementById("cemail").focus;
   return false;
}



   passwo=document.getElementById("cpass").value;
   cpasswo=document.getElementById("cfpass").value;
   if(passwo=="" || passwo=="")
   {
      alert("Passwords Empty");
      return false;
   }
  else if(passwo != cpasswo)
   {
      alert("Passwords does not match");
      return false;
   }
}
