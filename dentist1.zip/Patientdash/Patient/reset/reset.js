
$(document).ready(function(){
     
      
      
      $('#oldpsw').blur(function()
       {
         
         var oldps = $("#oldpsw").val();
           if( oldps =="")
           {
            swal({
               title: 'OOps!!',
               text: 'Enter old password',
               icon: 'warning'
             });
           }
           else if (!oldps.match(/^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/))
           {
            swal({
               title: 'OOps!!',
               text: 'Password should be 8 letters minimum and should contain an uppercase,lowercase and a special charecter',
               icon: 'warning'
             });  
           }
       
    }); 

    $('#newpassword').blur(function()
    {
      
      var ps = $("#newpassword").val();
        if( ps =="")
        {
         swal({
            title: 'OOps!!',
            text: 'Enter new password',
            icon: 'warning'
          });
        }
        else if (!ps.match(/^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/))
        {
         swal({
            title: 'OOps!!',
            text: 'Password should be 8 letters minimum and should contain an uppercase,lowercase and a special charecter',
            icon: 'warning'
          });  
        }
    
 }); 

 $('#cnewpassword').blur(function()
 {
   
   var ps = $("#cnewpassword").val();
     if( ps =="")
     {
      swal({
         title: 'OOps!!',
         text: 'Confirm new password',
         icon: 'warning'
       });
     }
     else if (!ps.match(/^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/))
     {
      swal({
         title: 'OOps!!',
         text: 'Password should be 8 letters minimum and should contain an uppercase,lowercase and a special charecter',
         icon: 'warning'
       });  
     }
 
});


$('#reset_psw').click(function()
 {
   var ops = $("#oldpsw").val();
   var ps = $("#newpassword").val();
   var cps = $("#cnewpassword").val();
   if(ps == "" || cps == "" || ops == "")
   {
      swal({
         title: 'OOps!!',
         text: 'Enter Passwords',
         icon: 'warning'
       });
   }
   else if( ps !== cps)
     {
      swal({
         title: 'OOps!!',
         text: 'Passwords Doesnot Match',
         icon: 'warning'
       });
     }
     else
     {
  // $.ajax({
  //     url: "/printer/Admin/reset/pass.php",
  //     type: "POST",
  //     data: {oldp : oldps ,
  //            newp :newps},
  //    success: function(response){
  //   if(response == 1){
    
  //     swal("Success", "Password Reset Success", "Success");
  //   }
  //   else{
  //     swal("Error", "Password Reset error", "Error");
  //   }
  //   }
  //   });
     }
    
 
});
});