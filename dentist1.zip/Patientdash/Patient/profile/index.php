<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Profile</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600&display=swap" rel="stylesheet" />
    <link href="fontawesome/css/all.min.css" rel="stylesheet" />
    <link href="css/tooplate-chilling-cafe.css" rel="stylesheet" />
    <link rel="stylesheet" href="style.css">
<!--
Tooplate 2118 Chilling Cafe
https://www.tooplate.com/view/2118-chilling-cafe
-->

  </head>
  <style>
  .form_error
  {
      color:red;
  }
  .form-register
  {
    width: 700px;
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 700px;
  margin: 0 auto 100px;
  padding: 45px;
  margin-top:40px;
  }
</style>
  <body background="">
   
    
    <div class="tm-container">
      <div class="tm-text-white tm-page-header-container">
        <i class="fas fa-edit fa-2x tm-page-icon"></i>
             </div>
      <div class="tm-main-content">
        
        <!-- Coffee Menu -->
        <center>
        
          <form class="form-register" method="post" action="#" name="register" novalidate>
            
 
        <section class="tm-section">
          
          <div class="tm-responsive-table">
           <div>
            <p>
              <label for="unit">Name  <br>
              <input type="text"  id="txt_Username"  name="name" style="width: 200px;height:20px" >	
              <br>
              <span class="form_error" id="Usr_name_error">Invalid Username</span>  
            </p>

              <p>
                <label for="unit">Address<br>
                <input type="text"  id="txt_Address" name="address" style="width: 200px;height:20px" />	
                <br>
                <span class="form_error" id="Usr_address_error">Invalid Address</span>  
              </p>

              <p>

                <p>
                  <label for="unit">Phone<br>
                  <input type="text" id="txt_Phone" name="ph" style="width: 200px;height:20px" />	
                  <br>
                  <span class="form_error" id="Usr_phone_error">Invalid Phone</span>
                </p>

                <p>
                  <label for="unit">Alt Phone<br>
                  <input type="text" id="txt_altPhone" name="ph1" style="width: 200px;height:20px" />	
                  <br>
                  <span class="form_error" id="Usr_phone_error">Invalid Phone</span>
                </p>

                  <p>
                    <label for="unit">Email <br>
                    <input type="text" id="txt_Email" name="mail" style="width: 200px;height:20px"/>	
                    <br>
                    <span class="form_error" id="Usr_email_error">Invalid Email</span>  
                  </p>

             
                 
                </select>
	
                      </p>
                      <div class="space-top text-center">
              
                    <button type="button" class="button" id="btn_update" style="width: 100px;height:20px">Update</button>
                    <button type="button" class="button" id="btn_edit"style="width: 100px;height:20px">Edit</button>
                   </div> 

                  </form>
                </center>
           
             
              
              
             
           
          </div>
        </section>

        

        
    </div>
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2'></script>
    <script>
      $(function() {
        // Adjust intro image height based on width.
        $(window).resize(function() {
          var img = $("#tm-intro-img");
          var imgWidth = img.width();

          // 640x425 ratio
          var imgHeight = (imgWidth * 425) / 640;

          if (imgHeight < 300) {
            imgHeight = 300;
          }

          img.css("min-height", imgHeight + "px");
        });
      });
    </script>
<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
 
  <script>
  $( document ).ready(function() {
   //alert("hai");
   addr = false;
   uname = false;
   email = false;
   phone = false;
   altphone = false;
   hidebutton();
   details_load();



   $("#btn_edit").click(function()
  {
    $("#btn_update").show(); 
    $('input').attr('disabled',false);
    $("#btn_edit").hide();
  });


  $("#btn_update").click(function()
  {
    //alert("clicked");
   if(addr == false && uname == false && email == false && phone == false)
   {
     $.ajax({
       url: "/DentalClinicManagement/dentist/Doctordash/Doctor/profile/details_update.php",
       method:"POST",
       data :{address : $("#txt_Address").val(),
              name : $("#txt_Username").val(),
              email : $("#txt_Email").val(),
              phone : $("#txt_Phone").val(),
              altphone : $("#txt_altPhone").val()
            },
      success : function(response)
      {
        if(response == "1")
        {
          Swal.fire({
            title: 'Update Success',
            text: "Profile Updated",
            icon: 'success',
            confirmButtonColor: '#6C24FA',
            confirmButtonText: 'OK',
            timer:2500
          }).then(function()
          {
            hidebutton();
            details_load();
          });

        }
        else
        {
          Swal.fire({
            title: 'Update Failed',
            text: "Something went wrong",
            icon: 'error',
            confirmButtonColor: '#fa3624',
            confirmButtonText: 'OK',
            timer:2500
          }).then(function()
          {
            hidebutton();
            details_load();
          });
        }
      }
     });
   }
   
  });


  $("#txt_Username").bind('input propertychange', function () {
    check_username();
  });

  $("#txt_Username").bind('focusout', function () {
    check_username_length(check_username);
  });

  $("#txt_Address").bind('focusout', function () {
    var address=$("#txt_Address").val();
    var pattern=/^[#.0-9a-zA-Z\s,-]+$/;
    if(pattern.test(address) && address !== ''){
      $("#Usr_address_error").hide();
      $("#txt_Address").css("border", "1px solid #ced4da");
      addr = false;
    }
    else {
    $("#Usr_address_error").html("Invalid Address");
    $("#Usr_address_error").show();
    $("#txt_Address").css("border", "2px solid red");
    addr = true;
  }

    //alert(address);
  });

  $("#txt_Phone").bind('focusout', function () {
    check_phone();
  });
  $("#txt_altPhone").bind('focusout', function () {
    check_phone();
  });

  $("#txt_Email").bind('focusout', function () {
    check_email();
  });

  function check_username() {
  var pattern = /^[a-zA-Z ]*$/;
  var usrname = $("#txt_Username").val();
  if (pattern.test(usrname) && usrname !== '') {
    $("#Usr_name_error").hide();
    $("#txt_Username").css("border", "1px solid #ced4da");
    uname = false;
  }
  else {
    $("#Usr_name_error").html("name should contain only letters  and Spaces");
    $("#Usr_name_error").show();
    $("#txt_Username").css("border", "2px solid red");
    uname = true;
  }
}

function check_username_length(callback) {
  var usrname = $("#txt_Username").val();
  if (usrname.length < 5) {
    $("#Usr_name_error").html("Name should contain at least 5 Characters");
    $("#Usr_name_error").show();
    $("#txt_Username").css("border", "2px solid red");
    uname = true;
  }
  else if (usrname.length > 20) {
    $("#Usr_name_error").html("Name should not exceed 20 Characters");
    $("#Usr_name_error").show();
    $("#txt_Username").css("border", "2px solid red");
    uname = true;
  }
  else {
    $("#Usr_name_error").hide();
    $("#txt_Username").css("border", "1px solid #ced4da");
    uname = false;
    callback.call();
  }
}



  function hidebutton(){
    $("#btn_update").hide();
    $("#btn_edit").show();
    $(".form_error").hide();
    $('input').attr('disabled','disabled');
  } 


function details_load()
{
  $.ajax({
    url:"C:/DentalClinicManagement/dentist/Doctordash/Doctor/profile/details_load.php",
    success:function(response)
    {
      var data = jQuery.parseJSON(response);
        
         $("#txt_Username").val(data["Username"]);
         $("#txt_Address").val(data["Address"]);
         $("#txt_Email").val(data["Email"]);
         $("#txt_Phone").val(data["Phone"]);
         $("#txt_altPhone").val(data["AltPhone"]);
    }
  });
}

function check_phone() {
  var pattern = /(((^[\+,0][9][1])(((\s[0-9]{7,10})|(\S[0-9]{7,10}))|([-]\S[0-9]{7,10})))|((^[\+,0][2]{2,2})((\S[0-9]{7,8})|((([-])[0-9]{7,8})|(\s[0-9]{7,8})))))|(((^[6,7,8,9][0-9]{9,9}))|(^[0,\+](([9][1)|[6,7,8,9]))[0-9]{8,9}))/;
  var uphone = $("#txt_Phone").val();
  if (uphone.length != 10) {
    $("#Usr_phone_error").html("Phone number must be 10 digits");
    $("#Usr_phone_error").show();
    $("#txt_Phone").css("border", "2px solid red");
    phone = true;
  }
  else if (pattern.test(uphone) && uphone !== '') {
    $("#Usr_phone_error").hide();
    $("#txt_Phone").css("border", "1px solid #ced4da");
    phone = false;
  }
  else {
    $("#Usr_phone_error").html("Invalid Phone number  format");
    $("#Usr_phone_error").show();
    $("#txt_Phone").css("border", "2px solid red");
    phone = true;

  }
}

function check_email() {
  var pattern = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
  var uemail = $("#txt_Email").val();
  if (pattern.test(uemail) && uemail !== '') {
    $("#Usr_email_error").hide();
    $("#txt_Email").css("border", "1px solid #ced4da");
    email = false;
  }
  else {
    $("#Usr_email_error").html("Invalid email format");
    $("#Usr_email_error").show();
    $("#txt_Email").css("border", "2px solid red");
    email = true;
  }
}







});
</script>

  </body>
</html>