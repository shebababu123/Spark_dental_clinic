$('#date').on('change', function() {
  var docid=$('#did').val();
  var datid=$('#dt').val();
  $.ajax({
    url: "/DentalClinicManagement/dentist/Patientdash/Patient/slot.php",
    type: "POST",
    data: {adate : datid,did : docid},
    success: function (response) {
      $('#slot').html(response);
    }
  });
});