<?php
include 'dbconnect.php';
$sdate=$_POST["sdate"];
$did=$_POST["did"];
$query="select a.Slots,b.Doctor_id,b.S_Date,b.Slot_id from tbl_addtimeslot a JOIN tbl_schedule b ON a.Time_id=b.Slot_id  AND b.S_Date='$sdate' AND b.Doctor_id='$did'";
$result=mysqli_query($con,$query);
if ( $result->num_rows > 0)
{
  echo '<option value="">Select a slot</option>';
    while($row = $result->fetch_assoc()) 
    {
      echo '<option value="'.$row["Slot_id"].'">'.$row["Slots"].'</option>';
    }
}
else
{
  echo '<option value="">No slots available</option>';
}
?>