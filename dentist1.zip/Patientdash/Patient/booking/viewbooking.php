<?php
include 'dbconnect.php';
session_start();
if(isset($_SESSION['loginid'])){
  $p=$_SESSION['loginid'];
  $qu=mysqli_query($con,"select * from tbl_patientreg where Login_id='$p'") or die(mysqli_error($con));
  while($qw=mysqli_fetch_array($qu))
  {
  $pid=$qw['Patient_id'];
  
  }
          $qu1=mysqli_query($con,"SELECT * from tbl_appointdoc where Patient_id='$pid'");
          $qw1=mysqli_fetch_array($qu1);
          $appid=$qw1['Appoint_id'];
          $d=$qw1['Doctor_id'];
          $appdt=$qw1['Appoint_date'];
          $sl=$qw1['Time_id'];

          $qu2=mysqli_query($con,"SELECT * from tbl_adddoctor where Doctor_id='$d'");
          $qw2=mysqli_fetch_array($qu2);
          $dname=$qw2['D_name'];
          $spc=$qw2['D_specialization'];
         
          $i=mysqli_query($con,"SELECT a.specialization,b.D_specialization from tbl_specialization a JOIN tbl_adddoctor b ON a.Spec_id=b.D_specialization where b.D_specialization='$spc'");
          $r1=mysqli_fetch_array($i);
          $sp=$r1['specialization'];

          $im=mysqli_query($con,"SELECT a.Slots,b.Time_id from tbl_addtimeslot a JOIN tbl_appointdoc b ON a.Time_id=b.Time_id where b.Time_id='$sl'");
          $r2=mysqli_fetch_array($im);
          $tm=$r2['Slots'];



         
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Booking</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script>
  $(document).ready(function() {
        $("#datepicker").datepicker({
            dateFormat: 'yy-mm-dd'
        });    
        $('.fa-calendar').click(function() {
        $("#datepicker").focus();
        });

    });
  </script>
  <!-- Favicons -->
  <link href="addc/img/favicon.png" rel="icon">
  <link href="addc/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Roboto:100,300,400,500,700|Philosopher:400,400i,700,700i" rel="stylesheet">

  <!-- Bootstrap css -->
  <!-- <link rel="stylesheet" href="css/bootstrap.css"> -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.theme.default.min.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/modal-video/css/modal-video.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/table.css" rel="stylesheet">
  <link rel="stylesheet" href="css/admin.css">
  
<style>
@import url(https://fonts.googleapis.com/css?family=Roboto:300);


.form {
  width: 600px;
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 600px;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: left;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #FFF;
  width: 100%;
  border-color: #4CAF50;
  border-radius:50px;
  padding: 15px;
  color: #4CAF50;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form button:hover,.form button:active,.form button:focus {
  background: #43A047;
  color: #FFF;
  border-color: #FFF;
  
}

.profile_pic{
    width:35%;
    float:left;

  }
  *, *:before, *:after {
    box-sizing: border-box;
}
.profile_info {
  padding: 25px 10px 10px;
  width: 65%;
  float: left;
}
.img-circle.profile_img {
  width: 50%;
  background: #fff;
  margin-left: 15%;
  z-index: 1000;
  position: inherit;
  margin-top: 15px;
  border: 1px solid rgba(52,73,94,0.44);
  padding: 3px;
}
.img-circle {
  border-radius: 50%;
}
fieldset {
  max-height:130px;
}
</style>
</head>


<body>

  <header id="header" class="header header-hide">
    <div class="container">
    

      <div id="logo" class="pull-left">
        
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="#body"><img src="img/logo.png" alt="" title="" /></a>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
        

        </ul>
      </nav>

    </div>
  </header><!-- #header -->


  
  <section id="get-started" class="padd-section text-center wow fadeInUp">


    <div class="container">
  <div class="section-title text-center">
      <div class="login-page" style="padding-top:150px;">
          <div class="form">
            <form class="login-form" action="" method="POST" id="reg" autocomplete="off" style="font-family: Georgia ;">
            <div class="d-flex">
	    		<div class="form-group mr-2"> 
                    <fieldset>
                        <div class="profile clearfix">
                            <div class="profile_pic">   			
                                    <?php
                                        include 'dbconnect.php';          
           
                                        $imag=mysqli_query($con,"select D_photo from tbl_adddoctor where Doctor_id='$d'");
                                        while($r=mysqli_fetch_array($imag))
                                        {
                                            $img=$r['D_photo'];
                                            echo '<img src="data:D_photo/jpg;base64,'.base64_encode($img).'" class="img-circle profile_img">';
                                        }
                                    ?>
                            </div>
                            <br><br>		
                            <label name="dname" style="color:Black;font-size: 18px;">Doctor Name: <?php echo $dname; ?></label><br><br>
                            <label name="spc" style="color:Black;font-size: 17px;">Specialized in: <?php echo $sp; ?></label><br>
                        </div>
	    					
                    </fieldset>
                </div>
            </div>   <br>    
            <div class="d-flex">
	    		<div class="form-group mr-2"> 

                <label for="" class="label" style="padding-right: 28px; padding-left: 10px;color: Black;font-size: 17px;">Appointment Date:</label>
                <label name="da" style="color:Black;font-size: 18px;"><?php echo $appdt; ?></label>
                </div>
                
            </div><br>
            <div class="d-flex">
	    		<div class="form-group mr-2"> 

                <label for="" class="label" style="padding-right: 120px; padding-left: 10px;color: Black;font-size: 17px;">Time:</label>
                <label name="tm" style="color:Black;font-size: 18px;"><?php echo $tm; ?></label>
                </div>
                
            </div>
            <br>
            <div class="d-flex">
	    		<div class="form-group mr-2"> 

                <label for="" class="label" style="padding-right: 30px; padding-left: 10px;color: Black;font-size: 17px;">Appointment RefId:</label>
                <label name="tm" style="color:Black;font-size: 18px;"><?php echo $appid; ?></label>
                </div>
                
            </div>

            <div class="group" >
	              		<center><input type="submit" name="submit" value="Cancel" id="submit" style="font-size: 16px; background: #DE006F;width: 170px;" class="btn btn-primary py-3 px-4"></center>
	            </div>
                
            </form>
       </div>
     </div>
</div>
<script src="jquery-3.1.1.min.js"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 


    <div class="container">
      <div class="row">

        
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/modal-video/js/modal-video.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="js/main.js"></script>
  <script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
 			<script src="js/jquery-ui.js"></script>			
			<script src="js/owl.carousel.min.js"></script>						
			<script src="js/jquery.nice-select.min.js"></script>							
			<script src="js/mail-script.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="addc/contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
 

</body>
</html>

<?php
}
else
{
  echo "<script>window.location.href='viewbooking.php';</script>";
}
?>

