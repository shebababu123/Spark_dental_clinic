<?php
session_start();
if(isset($_SESSION['loginid'])){
  include('dbconnect.php');
  $paid=$_SESSION['loginid'];
}
  
?>
<html>
<head>
<link rel="stylesheet" href="\DentalClinicManagement\dentist\Patientdash\Patient\viewbooking\css\customerview.css">
<nav id="nav-menu-container">
        <ul class="nav-menu">
          

        </ul>
      </nav>
</head>
<body>
 <table>
 
     <thead>
            <tr>
               <th colspan="6" style="font-size:35px;color:black;"> View Appointments</th>
            </tr>
            <tr style="background-color:blue;">
                <th>Index.</th>
                <th>Doctor Name</th>
                <th>Specialization</th>
                <th>Appointment Date</th>
                <th>Time</th>
                <th>Appointment Refid</th>
                <th>Action</th>
                
            </tr>
    </thead>
          <tbody>
                          <?php 
                          include "dbconnect.php";
                          $query="SELECT * from tbl_appointdoc,tbl_patientreg where tbl_appointdoc.Patient_id=tbl_patientreg.Patient_id AND tbl_patientreg.Patient_id='$paid'";
                          $result = mysqli_query($con,$query) or die(mysqli_error());
                         if ($result->num_rows > 0)
                          {
                            $i=1;
                            while($row = $result->fetch_assoc()) 
                            {
                                
                                $dat=$row['Appoint_date'];
                                $tm=$row['Time_id'];
                                $refid=$row['Appoint_id'];
                                $d=$row['Doctor_id'];
                                $q2="select * from tbl_adddoctor where Doctor_id=$d";
                                $s2=mysqli_query($con,$q2);
                                while ($r2=mysqli_fetch_array($s2)) {
                                $name=$r2['D_name'];
                                $sp=$r2['D_specialization'];

                                $q3="select * from tbl_specialization where Spec_id=$sp";
                                $s3=mysqli_query($con,$q3);
                                while ($r3=mysqli_fetch_array($s3)) {
                                $spec=$r3['specialization'];

                                $q4="select * from tbl_addtimeslot where Time_id=$tm";
                                $s4=mysqli_query($con,$q4);
                                while ($r4=mysqli_fetch_array($s4)) {
                                  $tim=$r3['Slots'];

                           echo "<tr style='color:black;'><td>".$i."</td><td>$name</td><td>$spec</td><td>$dat<td>$tim</td><td>$refid</td>";?>

                        <td>
                        <a href="\DentalClinicManagement\dentist\Patientdash\Patient\viewbooking\cancel.php?id=<?php echo $row["Appoint_id"]; ?>" ><button class="Edit">Cancel</button></a>
					
                          </td>
						  </tr>
                          <?php
                           ++$i;
                            }
                        }
                    }
                }
                            
                          }
                          else
                          {
                            echo '<script language="javascript">';
                            echo 'alert("No Appointments")';
                            echo '</script>';
                          }
                          $con->close();
                          ?>
                          
                        </tbody>
                      </table>
<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/pr/customer/js/jquery-3.1.1.min.js"></script>
<script src="/pr/customer/js/js"></script>
<script>

</script>
</body>
</html>
