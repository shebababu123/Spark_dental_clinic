<?php
include 'dbconnect.php';
session_start();
if(isset($_SESSION['loginid'])){
  $p=$_SESSION['loginid'];
  $qu=mysqli_query($con,"select concat(PF_name, PL_name) as Pname,Patient_id,P_DOB,P_Gender,P_Address,P_Phone from tbl_patientreg where Login_id='$p'") or die(mysqli_error($con));
  while($qw=mysqli_fetch_array($qu))
  {
  $pid=$qw['Patient_id'];
  $pname=$qw['Pname'];
  $add=$qw['P_Address'];
  $ph=$qw['P_Phone'];
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>case Report</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="addc/img/favicon.png" rel="icon">
  <link href="addc/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Roboto:100,300,400,500,700|Philosopher:400,400i,700,700i" rel="stylesheet">

  <!-- Bootstrap css -->
  <!-- <link rel="stylesheet" href="css/bootstrap.css"> -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.theme.default.min.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/modal-video/css/modal-video.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/table.css" rel="stylesheet">
  
<style>
@import url(https://fonts.googleapis.com/css?family=Roboto:300);


.form {
  width: 1000px;
  position: relative;
  z-index: 1;
  background: #002366;
  max-width: 1000px;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: left;
  color:white;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form label{
  color:white;
}
.form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #FFF;
  width: 100%;
  border-color: #4CAF50;
  border-radius:50px;
  padding: 15px;
  color: #4CAF50;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form button:hover,.form button:active,.form button:focus {
  background: #43A047;
  color: #FFF;
  border-color: #FFF;
  
}
input [type=radio] {
  width:15px;
  height:15px;

}

input.t {
  width:14px;
  height:14px;
  

}
input.t1 {
  width:14px;
  height:14px;
 

}
input.t2 {
  width:14px;
  height:14px;
}


</style>
<script type="text/javascript">
    function ShowHideDiv() {
        var hos = document.getElementById("hos");
        var dvdetail = document.getElementById("dvdetail");
        dvdetail.style.display = hos.checked ? "block" : "none";
    }

    function ShowHideDiv1() {
        var d = document.getElementById("d");
        var dvdetail1 = document.getElementById("dvdetail1");
        dvdetail1.style.display = d.checked ? "block" : "none";
    }

    function ShowHideDiv2() {
        var p = document.getElementById("p");
        var dvdetail2 = document.getElementById("dvdetail2");
        dvdetail2.style.display = p.checked ? "block" : "none";
    }

</script>
    
</head>


<body>

  <header id="header" class="header header-hide">
    <div class="container">
    

      <div id="logo" class="pull-left">
        
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="#body"><img src="img/logo.png" alt="" title="" /></a>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
        

        </ul>
      </nav>

    </div>
  </header><!-- #header -->

 <!-- <section id="hero" class="wow fadeIn">
    <div class="hero-container">

      
      <a href="#get-started" class="btn-get-started scrollto">ADD Doctor</a>
      <table class="rwd-table">
        
        
       </table>
    </div>
  </section>--><!-- #hero -->

  
  <section id="get-started" class="padd-section text-center wow fadeInUp">


    <div class="container">
  <div class="section-title text-center">
      <div class="login-page" style="padding-top:150px;">
          <div class="form">
            <form class="login-form" action="" method="POST" id="reg" autocomplete="off" style="font-family: Georgia ;" enctype="multipart/form-data">
                			
	    				<div class="d-flex">
	    					<div class="form-group mr-2">
							      <label for="" class="label"style="padding-left: 20px;font-size: 20px;">Doctor Name: </label>	
							
		                    <select name="doctor" id="" class="form-control" style="width: 220px;height:40px">
		                      	<option value="">Select Doctorname</option>
								                <?php 
								                    include 'dbconnect.php'; 
								                      $q3="select D_name,Doctor_id from tbl_adddoctor";
								                    $ch3=mysqli_query($con,$q3);
							  	                  while($data2=mysqli_fetch_array($ch3))
								                    {
								                        $d3=$data2["Doctor_id"];
								                          echo "<option value=$d3>"; echo $data2["D_name"]; } echo "</option>";
								                      ?>
		                      </select>

                          <label for="" class="label"style="font-size: 20px;  padding-left: 5px;">S.No: </label>
                          <input type="text" name="sno" style="width: 100px;"value="<?php echo $pid;?>" >

                          <label for="" class="label"style="font-size: 20px; padding-left: 5px;">OP.No: </label>
                          <input type="text" name="opno" style="width: 100px;"value="<?php echo $pid;?>" >
                          <label for="" class="label"style="font-size: 20px;">Date: </label>
                          <input type="date" name="date" value="<?php echo $date= date("Y-m-d");  ?>" >
							    </div>
                </div>
                        
							
                <div class="d-flex">
	    					<div class="form-group mr-2">
							              <label for="" class="label"style="padding-left: 20px;font-size: 20px;">Patient Name: </label>	
                           <input type="text" name="pname" style="width: 100px;"value="<?php echo $pname;?>"  >
		                    

                          <label for="" class="label"style="font-size: 20px;  padding-left: 5px;">Occupation: </label>
                          <input type="text" name="occu" style="width: 100px;" >

                          <label for="" class="label"style="font-size: 20px; padding-left: 7px;">Marital Status: </label>
                          <input type="radio" name="g1"class="g" value="married"style="font-size: 18px;padding-left: 2px;"><font size="4.5px" color="white"> Married</font>
                          <input type="radio" name="g1" class="g"value="single" style="font-size: 18px;padding-left: 2px;"><font size="4.5px" color="white"> Single</font>
                          
                             <br>
                             <label for="" class="label"style="font-size: 20px;  padding-left: 5px;">Address/Ph.no: </label>
                             <textarea name="add" rows="6" cols="130" value="<?php echo $add;?>','<?php echo $ph;?>"> </textarea>         
							    </div>
                </div>
                <br> <br>
                  <h3 style="color:red; padding-left:10px;heifht:10px;"><b> DENTAL HISTORY</b></h3><br><br>
                  
                  <div class="d-flex">
	    					<div class="form-group mr-2">
							              
                             
                             <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 51px;">Chief Complaint: </label>
                             <textarea name="com" rows="3" cols="80" style="margin-bottom:10px;"> </textarea><br>
                             <label for="" class="label"style="font-size: 20px;  padding-left: 4px; padding-right: 5px;">History of past illness: </label>
                             <textarea name="his" rows="6" cols="80" style="margin-bottom:10px;"> </textarea><br>
                             <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 21px;">Past Dental History: </label>
                             <textarea name="past" rows="6" cols="80"> </textarea>         
							    </div>
                </div>

                <br> <br>
                  <h3 style="color:red; padding-left:10px;heifht:10px;"><b> PAST MEDICAL HISTORY</b></h3>
                  <h4 style="color:red; padding-left:10px;heifht:10px;"><b> ANY RELATED DISEASES TO:</b></h4><br><br>
                  
                <div class="d-flex">
	    					<div class="form-group mr-2">
                      <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 20px;">Cardiovascular: </label>
                      <input type="radio" name="g2" value="yes" class="y" style="font-size: 18px;padding-left: 2px;"> <font size="4.5px" color="white">YES</font>
                      <input type="radio" name="g2" checked="checked"value="no" class="y" style="font-size: 18px;padding-left: 2px;">  <font size="4.5px" color="white">No </font><br>

                      <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 51px;">Hepatic: </label>
                      <input type="radio" name="g3" value="yes" class="y" style="font-size: 18px;padding-left: 2px;"> <font size="4.5px" color="white">YES</font>
                      <input type="radio" name="g3" checked="checked"value="no" class="y" style="font-size: 18px;padding-left: 2px;">  <font size="4.5px" color="white">No </font><br>

                      <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 30px;">Respiratory: </label>
                      <input type="radio" name="g4" value="yes" class="y" style="font-size: 18px;padding-left: 2px;"> <font size="4.5px" color="white">YES</font>
                      <input type="radio" name="g4" checked="checked"value="no" class="y" style="font-size: 18px;padding-left: 2px;">  <font size="4.5px" color="white">No </font><br>

                      <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 51px;">Renal: </label>
                      <input type="radio" name="g5" value="yes" class="y" style="font-size: 18px;padding-left: 2px;"> <font size="4.5px" color="white">YES</font>
                      <input type="radio" name="g5" checked="checked"value="no" class="y" style="font-size: 18px;padding-left: 2px;">  <font size="4.5px" color="white">No </font><br>

                      <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 51px;">Gastrointestinal: </label>
                      <input type="radio" name="g6" value="yes" class="y" style="font-size: 18px;padding-left: 2px;"> <font size="4.5px" color="white">YES</font>
                      <input type="radio" name="g6"checked="checked" value="no" class="y" style="font-size: 18px;padding-left: 2px;">  <font size="4.5px" color="white">No </font><br>

                      <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 51px;">Endocrine<br>(Diabetes): </label>
                      <input type="radio" name="g7" value="yes" class="y" style="font-size: 18px;padding-left: 2px;"> <font size="4.5px" color="white">YES</font>
                      <input type="radio" name="g7" checked="checked"value="no" class="y" style="font-size: 18px;padding-left: 2px;">  <font size="4.5px" color="white">No </font><br>

                      <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 51px;">Neural: </label>
                      <input type="radio" name="g8" value="yes" class="y" style="font-size: 18px;padding-left: 2px;"> <font size="4.5px" color="white">YES</font>
                      <input type="radio" name="g8"checked="checked" value="no" class="y" style="font-size: 18px;padding-left: 2px;">  <font size="4.5px" color="white">No </font><br>

                      <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 51px;">If yes,give details: </label>
                      <textarea name="detail" rows="6" cols="80" style="margin-bottom:10px;"> </textarea>
                      <br>
                      <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 51px;">Allergic to: </label>
                      <input type="text" name="allergic" style="width: 150px;" >
                       <br>
                       <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 51px;">Have you been hospitalized/operated : </label>
                       <input type="radio" name="g9" value="yes"id="hos" class="y"  onclick="ShowHideDiv()"style="font-size: 18px;padding-left: 2px;"> <font size="4.5px" color="white">YES</font>
                      <input type="radio" name="g9"checked="checked" value="no" class="y"onclick="ShowHideDiv()" style="font-size: 18px;padding-left: 2px;">  <font size="4.5px" color="white">No </font><br>
                      <div id="dvdetail" style="display: none">
                      <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 51px;">If yes,give details: </label>
                      <textarea name="detail1" rows="6" cols="80" style="margin-bottom:10px;" id="text"> </textarea>
                      </div>
                      <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 51px;">Do you have any history of abnormal bleeding with trauma or dental procedures: </label>
                      <input type="radio" name="g10" value="yes" id="d"class="y" onclick="ShowHideDiv1()style="font-size: 18px;padding-left: 2px;"> <font size="4.5px" color="white">YES</font>
                      <input type="radio" name="g10" checked="checked"value="no" class="y"onclick="ShowHideDiv1() style="font-size: 18px;padding-left: 2px;">  <font size="4.5px" color="white">No </font><br>
                      <div id="dvdetail1" style="display: none">
                      <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 51px;">If yes,give details: </label>
                      <textarea name="detail2" rows="6" cols="80" style="margin-bottom:10px;"> </textarea>
                      </div>
                        <br>
                        <label for="" class="label"style="font-size: 20px;  padding-left: 5px; padding-right: 51px;">Are you pragnant: </label>
                        <input type="radio" name="g11" value="yes" id="p" class="y"  onclick="ShowHideDiv2()style="font-size: 18px;padding-left: 2px;"> <font size="4.5px" color="white">YES</font>
                      <input type="radio" name="g11" checked="checked"value="no" class="y"  onclick="ShowHideDiv2()style="font-size: 18px;padding-left: 2px;">  <font size="4.5px" color="white">No </font><br>
                      <div id="dvdetail2" style="display: none">
                      <input type="checkbox" name="pra[]" value="pra1" class="t"><label for="pra1" style="font-size: 20px; padding-right:10px;"> I TRIMESTER</label>
                      <input type="checkbox" name="pra[]" value="pra2" class="t1"><label for="pra2" style="font-size: 20px; padding-right:10px;"> II TRIMESTER </label>
                      <input type="checkbox" name="pra[]" value="pra3" class="t2"><label for="pra3" style="font-size: 20px;"> III TRIMESTER </label><br>
                      </div>
                </div>
                </div>
                    
                
	            		<div class="group" align="center">
	              			<input type="submit" name="submit" align="middle" value="Submit" id="submit" style="font-size: 16px; background: #DE006F;width: 170px;" class="btn btn-primary py-3 px-4">
	            		</div>
            </form>
       </div>
     </div>
</div>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
    jQuery.validator.addMethod("noSpace", function(value, element) { 
    return value == '' || value.trim().length != 0;  
}, "No space please and don't leave it empty");
jQuery.validator.addMethod("phonenum", function(value, element) { 
    return this.optional( element ) || /^([7-9_\.\-])+(([0-9]))+$/.test( value ); 
}, "Please enter valid phone number");
jQuery.validator.addMethod("customEmail", function(value, element) { 
  return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.))+([a-zA-Z0-9]{2,4})+$/.test( value ); 
}, "Please enter valid email address!");

$.validator.addMethod("alphabetsnspace", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    });


$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, numbers, and underscores only please" );
var $ureg = $('#reg');
if($ureg.length){
  $ureg.validate({
      rules:{
          //occupation is the name of the textbox
          occu: {
              required: true,
              alphabetsnspace: true,
			        maxlength:15
              //alphanumeric is the custom method, we defined in the above
              
          },
		 
          g1:{
                required: true
                },
         com:{
                required: true,
                alphabetsnspace: true
                },
        his:{
                required: true,
                alphabetsnspace: true
                },	
        past:{
                required: true,
                alphabetsnspace: true
                },		
        g2:{
                required: true
                },
        g3:{
                required: true
                },   
        g4:{
                required: true
                },
        g5:{
                required: true
                },
        g6:{
                required: true
                },
        g7:{
                required: true
                },
        g8:{
                required: true
                }, 
        detail:{
                required:true
                

              },
        allergic:{
                required:true,
                alphabetsnspace: true
        },
        g9:{
                required: true
                },
      detail1:{
                required:true

              },
      g10:{
                required: true
                },
      detail2:{
                required:true

              },  
      g11:{
                required: true
                },
      pra[]: {
                required: true,
                maxlength: 2
            }
        
         
      },
      messages:{
          occu: {
              //error message for the required field
              required: 'Please enter your occupation',
              alphabetsnspace: 'only alphabets and space allowed'
          },
           g1: {
            required: 'Please select a marital Status!'
          },
          com: {
            required: 'Please enter your chief complaint ',
              alphabetsnspace: 'only alphabets and space allowed'
          },
          his: {
            required: 'Please enter your present illness history ',
              alphabetsnspace: 'only alphabets and space allowed'
          },
          his: {
            required: 'Please enter your past dental history ',
              alphabetsnspace: 'only alphabets and space allowed'
          },
          g2: {
            required: 'Please select a yes or no!'
          },
          g3: {
            required: 'Please select a yes or no!'
          },
          g4: {
            required: 'Please select a yes or no!'
          },
          g5: {
            required: 'Please select a yes or no!'
          },
          g6: {
            required: 'Please select a yes or no!'
          },
          g7: {
            required: 'Please select a yes or no!'
          },
          g8: {
            required: 'Please select a yes or no!'
          },
         detail:{
           required: 'If you have any one diseases Please give details!'
         },
         allergic:{
          required: 'Please enter if you have any allery of medicines!'
         },
         g9: {
            required: 'Please select a yes or no!'
          },
          detail1:{
           required: 'If you have been operated/hospitalized Please enter details!'
         },
         g10: {
            required: 'Please select a yes or no!'
          },
          detail2:{
           required: ' Please enter details of dental procedures!'
         },
         g11: {
            required: 'Please select a yes or no!'
          },
          
          pra[]: {
                required: "You must check at least 1 box",
                maxlength: "Check no more than {0} boxes"
            },
          
      },
      
  });
}
  </script>	

<?php 
		include 'dbconnect.php';
			if(isset($_POST['submit']))
			{

              $dt=$_POST['date'];
              $a=$_POST['occu'];
              $add=$_POST['add'];
              $doc=$_POST['doctor'];
              $sno=$_POST['sno'];
              $opno=$_POST['opno'];
			        $mrge=$_POST['g1'];
              $b=$_POST['com'];
              $c=$_POST['his'];
            $d=$_POST['past'];
            $e=$_POST['g2'];
            $f=$_POST['g3'];
            $g=$_POST['g4'];
            $h=$_POST['g5'];
            $i=$_POST['g6'];
            $j=$_POST['g7'];
            $k=$_POST['g8'];
            $de=$_POST['detail'];
            $all=$_POST['allergic'];
            $hos=$_POST['g9'];
            $d1=$_POST['detail1'];
            $hist=$_POST['g10'];
            $d2=$_POST['detail2'];
            $pr=$_POST['g11'];

            $checkbox1 = $_POST['pra'];
             $chk="";  
            foreach($checkbox1 as $chk1)  
             {  
                    $chk.= $chk1.",";  
            }  
		
			
  			
        $sql="INSERT INTO `tbl_casereport`(`Doctor_name`, `Sno`, `Pt_name`, `Op_no`, `Occupation`, `Date`, `Marital_Status`, `Address_ph`, `Chief_complaint`, `History_presentillness`, `Past_dentalhistory`, `Cardiovascular`, `Respiratory`, `Gas`, `Neural`, `Hepatic`, `Renal`, `Endrocrine`, `Detail1`, `Allergicto`, `Hospital_operate`, `Detail2`, `Ab_bleeding`, `Detail3`, `Pregnant`, `Trimester`) 
        VALUES ('$doc','$sno','$pid','$opno','$a','$dt','$mrge','$add','$b','$c','$d','$e','$f','$g','$h','$i','$j','$k','$de','$all','$hos','$d1','$hist','$d2','$d2','$pr','$chk')";
 				$ch=mysqli_query($con,$sql);
				if($ch)
				{
  				?>
   				<script>
 				alert("Casereport Inserted Successfully");
				window.location="casereport.php";
				</script>
				?>
        <?php
				}
				else
				{
  				echo"error:".$sql."<br>".mysqli_error($con);
				}
				}
				
				mysqli_close($con);
				?>
	


    <div class="container">
      <div class="row">

        
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/modal-video/js/modal-video.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="js/main.js"></script>
  <script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
 			<script src="js/jquery-ui.js"></script>			
			<script src="js/owl.carousel.min.js"></script>						
			<script src="js/jquery.nice-select.min.js"></script>							
			<script src="js/mail-script.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="addc/contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="addc/js/main.js"></script>
  

</body>
</html>


