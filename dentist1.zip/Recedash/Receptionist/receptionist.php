<?php
session_start();
if(isset($_SESSION['loginid'])){
  include('dbconnect.php');
?>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet">
    <link rel="stylesheet" href="css/admin.css">
  </head>
  <body>
    <aside class="side-nav" id="show-side-navigation1">
      <i class="fa fa-bars close-aside hidden-sm hidden-md hidden-lg" data-close="show-side-navigation1"></i>
      <div class="heading">
        
        <div class="info">
          <h3><a href="#">Spark Dental Care</a></h3>
          <p>DentalNurse Panel</p>
        </div>

      <ul class="categories">
        <li><i class="fa fa-home fa-fw" aria-hidden="true"></i><a href="#"> Home</a></li>
      <li class="reqfar"><i class="fa fa-list-alt" aria-hidden="true"></i><a href="#">HospitalPatients</a>
          <ul class="side-nav-dropdown">

            <li class="apatient"><a href="#">Add HospitalPatients</a></li>
            <li class="vpatient"><a href="#">View HospitalPatients</a></li>
              
                  </ul></li>
       <li><i class="fa fa-list-alt" aria-hidden="true"></i><a href="#">Presciption</a>
        <ul class="side-nav-dropdown">

        <li class="apres"><a href="#">Add Presciption</a></li>
        <li class="vpres"><a href="#">View Prescription</a></li>

              
              </ul></li>-->
            
        <!--<li class="aspec"><i class="fa fa-list-alt" aria-hidden="true"></i><a href="#">Add Specializations</a></li>
        <li class="leave"><i class="fa fa-list-alt" aria-hidden="true"></i><a href="#">LeaveRequest</a></li>
       <li class="apro"><i class="fa fa-shopping-basket" aria-hidden="true"></i><a href="#"> Add product</a></li>
        <li><i class="fa fa-window-close" aria-hidden="true"></i><a href="/pr/Admin/blockpro/product.php"> Block product</a></li>
        <li><i class="fa fa-window-close" aria-hidden="true"></i><a href="#"> View Stock</a></li>
        <li><i class="fa fa-window-close" aria-hidden="true"></i><a href="#"> View Sale Details</a></li> -->
      </ul>
    </aside>
    <section id="contents">  
      <nav class="navbar navbar-default">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
              <i class="fa fa-align-right"></i>
            </button>
            <a class="navbar-brand" href="#"><span class="main-color">Dashboard</span></a>
          </div>
          <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
              <li class="dropdown">
                <a href="\DentalClinicManagement\dentist\Recedash\Receptionist\profile\viewprofile.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">My profile <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="\DentalClinicManagement\dentist\Recedash\Receptionist\reset\reset.php"><i class="fa fa-user-o fw"></i>Reset Password</a></li>
                  <li role="separator" class="divider"></li>
                  <li><a href="logout.php"><i class="fa fa-sign-out"></i> Log out</a></li>
                </ul>
              </li>
              <li><a href="#"><i data-show="show-side-navigation1" class="fa fa-bars show-side-btn"></i></a></li>
            </ul>
          </div>
        </div>
      </nav>
      <div class="welcome">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="content">
                <h2>Dental Nurse</h2>
                <iframe id="iloadspace" STYLE="width:100%;height:620px;" FRAMEBORDER="no" BORDER="0"  seamless="seamless" ></iframe>
              
              </div>
            </div>
          </div>
        </div>
      </div>
      <section class="statistics">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-4">
              
            </div>
            <div class="col-md-4">
             
            </div>
            <div class="col-md-4">
              
            </div>
          </div>
        </div>
      </section>
      
      
  
        
      </section>
      <script src='http://code.jquery.com/jquery-latest.js'></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.js"></script>
      <script src='js/admin.js'></script>      
<script>
$(document).ready(function(){
  
  $('.leave').click(function () { 
    
          $('.content h2').contents().replaceWith('Leave Request');
          $('#iloadspace').attr('src','/DentalClinicManagement/dentist/Admindash/Admin/adddoctor/adddoctor.php');
           });


   $('.vpharmacist').click(function () { 
    
    $('.content h2').contents().replaceWith("View Pharmacist");
    $('#iloadspace').attr('src','/DentalClinicManagement/dentist/Admindash/Admin/viewpharmacist/viewpharmacist.php');
     });

     $('.vrecept').click(function () { 
    $('.content h2').contents().replaceWith("View Receptionist");
    $('#iloadspace').attr('src','/DentalClinicManagement/dentist/Admindash/Admin/viewreceptionist/viewreceptionist.php');
     });

     $('.vdoctor').click(function () { 
    $('.content h2').contents().replaceWith("View Doctor");
    $('#iloadspace').attr('src','/DentalClinicManagement/dentist/Admindash/Admin/viewdoctor/viewdoctor.php');
     });

     $('.vpatient').click(function () { 
    $('.content h2').contents().replaceWith("View Patient");
    $('#iloadspace').attr('src','/DentalClinicManagement/dentist/Admindash/Admin/viewpatient/viewpatient.php');
     });

     $('.adoctor').click(function () { 
    $('.content h2').contents().replaceWith("Add Doctor");
    $('#iloadspace').attr('src','/DentalClinicManagement/dentist/Admindash/Admin/adddoctor/adddoctor.php');
     });

     $('.arecept').click(function () { 
    $('.content h2').contents().replaceWith("Add Receptionist");
    $('#iloadspace').attr('src','/DentalClinicManagement/dentist/Admindash/Admin/addreceptionist/addreceptionist.php');
     });

     $('.apharmacist').click(function () { 
    $('.content h2').contents().replaceWith("Add Pharmacist");
    $('#iloadspace').attr('src','/DentalClinicManagement/dentist/Admindash/Admin/addpharmacist/addpharmacist.php');
     });

     

      });
            
                          
</script>
      </body>
    </html>
    <?php
}
else
{
  echo "<script>window.location.href='http://localhost/DentalClinicManagement/dentist/Signin.php';</script>";
}
?>