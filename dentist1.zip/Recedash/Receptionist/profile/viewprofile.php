<?php
include ('dbconnect.php');
session_start();

  $id=$_SESSION['loginid'];
  $sqll="select * from tbl_login where Login_id='$id'";
  $result1=mysqli_query($con,$sqll);
  $row=mysqli_fetch_array($result1);
  $email=$row['L_email'];
  $sql="select * from tbl_addreceptionist where Login_id='$id'";
  $d=mysqli_query($con,$sql);
  if(mysqli_num_rows($d)>0)
  {
  
  while($row=mysqli_fetch_array($d))
  { 
              $fname=$row['R_name'];
              $add=$row['R_address'];
              $ph=$row['R_phone'];
              $gen=$row['R_gender'];
              $quali=$row['R_qualification'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Profile</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="addc/img/favicon.png" rel="icon">
  <link href="addc/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Roboto:100,300,400,500,700|Philosopher:400,400i,700,700i" rel="stylesheet">

  <!-- Bootstrap css -->
  <!-- <link rel="stylesheet" href="css/bootstrap.css"> -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.theme.default.min.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/modal-video/css/modal-video.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="style.css" rel="stylesheet">
  <link href="css/table.css" rel="stylesheet">
  <style type="text/css">
		.error{
  color: #F00;
  background-color: #FFF;
		}
	</style>
  
<style>
@import url(https://fonts.googleapis.com/css?family=Roboto:300);


.form {
  width: 500px;
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 500px;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: left;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #FFF;
  width: 100%;
  border-color: #4CAF50;
  border-radius:50px;
  padding: 15px;
  color: #4CAF50;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form button:hover,.form button:active,.form button:focus {
  background: #43A047;
  color: #FFF;
  border-color: #FFF;
  
}
</style>
</head>
<body>

  <header id="header" class="header header-hide">
    <div class="container">
    
    <div class="back">
	<a href="\DentalClinicManagement\dentist\Recedash\Receptionist\receptionist.php"><font style="color:white;">Back</font></a>
	</div>
      <div id="logo" class="pull-left">
        
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="#body"><img src="img/logo.png" alt="" title="" /></a>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
        <div class="group" align="center">
          <a href="editpro.php"><input type="button" name="submit" align="middle" value="Edit Profile" id="submit" style="font-size: 16px; background: #DE006F;width: 180px;height:30px" class="btn btn-primary py-3 px-4"></a>
	            		</div>

        </ul>
      </nav>

    </div>
  </header>
  
  <section id="get-started" class="padd-section text-center wow fadeInUp">	
    <div class="container">
  <div class="section-title text-center">
      <div class="login-page" style="padding-top:150px;">
      <div class="form">
            <form class="login-form" action="" method="POST" id="reg" autocomplete="off" style="font-family: Georgia ;" enctype="multipart/form-data">
            <div class="">
          		<h2 align="center" style="color:#002366">MY PROFILE</h2>
						</div>
	    				<div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label"style="padding-right: 20px; padding-left: 20px;color: Black;font-size: 20px;">Full Name: </label>
							</div>
							<div class="form-group ml-2">
	    					<input type="text" name="fname" class="form-control" placeholder="Full name" value="<?php echo $fname;?>"readonly>
							</div>
                        </div>
                        
	    				<div class="d-flex">
	    					<div class="form-group mr-2">
	    					<label for="" class="label" style="padding-right: 10px; padding-left: 10px; color:Black;font-size: 20px;">Gender: </label></br>
							</div>
							<div class="form-group ml-2">
	    					<input type="text" name="gen" class="form-control" placeholder="Full name" value="<?php echo $gen;?>" readonly>
					        </div>
						</div>
						
						<div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label" style="padding-right: 20px; padding-left: 70px;color: Black;font-size: 20px;">Address: </label>
							</div>
							<div class="form-group ml-2">
	    					<input type="text" name="address" class="form-control" placeholder="Address" required value="<?php echo $add;?>" readonly>
							</div>
                        </div>
                      
              <div class="d-flex">
	    				<div class="form-group mr-2">
              <?php
                include 'dbconnect.php';
                $qu1=mysqli_query($con,"SELECT a.R_qualification,b.rquali FROM tbl_addreceptionist a JOIN tbl_rquali b ON a.R_qualification=b.Rquali_id AND R_qualification='$quali'");
                $qw1=mysqli_fetch_array($qu1);
                $qua=$qw1['rquali'];
                
                ?>
							<label for="" class="label" style="padding-right: 20px; padding-left: 70px;color: Black;font-size: 20px;">Qualification: </label>
							</div>
							<div class="form-group ml-2">
	    					<input type="text" name="quali" class="form-control"  value="<?php echo $qua;?>" readonly>
							</div>
							</div>
                
						<div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label" style="padding-right: 20px; padding-left: 70px;color: Black;font-size: 20px;">Phone: </label>
							</div>
							<div class="form-group ml-2">
	    					<input type="text" name="phone" class="form-control" placeholder="Phoneno" value="<?php echo $ph;?>" readonly> 
							</div>
                        </div>
                       
                        <div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label" style="padding-right: 20px; padding-left: 70px;color: Black;font-size: 20px;">Email : </label>
							</div>
							<div class="form-group ml-2">
	    					<input type="text" name="email" class="form-control" placeholder="email" value="<?php echo $email;?>"readonly > 
							</div>
	    				</div>
						
	            	
            </form>
       </div>
     </div>
</div>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  

<?php
  }
}
?>

    <div class="container">
      <div class="row">

        
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/modal-video/js/modal-video.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="js/main.js"></script>
  <script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
 			<script src="js/jquery-ui.js"></script>			
			<script src="js/owl.carousel.min.js"></script>						
			<script src="js/jquery.nice-select.min.js"></script>							
			<script src="js/mail-script.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="addc/contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="addc/js/main.js"></script>
  

</body>
</html>
