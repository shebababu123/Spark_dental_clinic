<?php
include 'dbconnect.php';
$myid=$_GET["id"];
//echo $myid;
mysqli_query($con,"delete from tbl_appointment where Appoint_id='$myid'");
header("Location:Viewappointment.php");
?>

