<html>
<head>
<link rel="stylesheet" href="/DentalClinicManagement/dentist/Patientdash/Patient/viewappointment/css/customerview.css">
<nav id="nav-menu-container">
        <ul class="nav-menu">
          

        </ul>
      </nav>
</head>
<body>
 <table>
 
     <thead>
            <tr>
               <th colspan="6" style="font-size:35px;color:black;">Appointment List</th>
            </tr>
            <tr style="background-color:blue;">
                <th>Index.</th>
                <th>Doctor Name</th>
                <th>Day</th>
                <th>Slot</th>
                <th>Appointment Date</th>
                <th>Action</th>
                
            </tr>
    </thead>
          <tbody>
                          <?php 
                          include "dbconnect.php";
                          $query="select * from tbl_adddoctor,tbl_appointment1 where tbl_adddoctor.Doctor_id=tbl_appointment1.Doctor_id";
                          $result = mysqli_query($con,$query) or die(mysqli_error());
                         if ($result->num_rows > 0)
                          {
                            $i=1;
                            while($row = $result->fetch_assoc()) 
                            {
                                $appo=$row['Appoint_id'];
                                $d=$row['Doctor_id'];
                                $da=$row['Day_id'];
                                $s=$row['Slot_id'];
                                $dat=$row['Date'];
                                $q2="select * from tbl_adddoctor where Doctor_id=$d";
                                $s2=mysqli_query($con,$q2);
                                while ($r2=mysqli_fetch_array($s2)) {
                                $name=$r2['D_name'];

                                $q3="select * from tbl_days where Day_id=$da";
                                $s3=mysqli_query($con,$q3);
                                while ($r3=mysqli_fetch_array($s3)) {
                                $days=$r3['Day'];

                                $q4="select * from tbl_timeslot where Slot_id=$s";
                                $s4=mysqli_query($con,$q4);
                                while ($r4=mysqli_fetch_array($s4)) {
                                $slotfrom=$r4['Slot_from'];
                                $slotto=$r4['Slot_to'];
                           echo "<tr style='color:black;'><td>".$i."</td><td>$name</td><td>$days</td><td>".$r4["Slot_from"].' - '.$r4["Slot_to"]."</td><td>$dat</td>";?>

                        <td>
                        <a href="/DentalClinicManagement/dentist/Admindash/Admin/leaveapproval/accept.php?id=<?php echo $row["Appoint_id"]; ?>" ><button class="Edit">Cancel</button></a>
					
                          </td>
						  </tr>
                          <?php
                           ++$i;
                            }
                        }
                    }
                }
                            
                          }
                          else
                          {
                            echo '<script language="javascript">';
                            echo 'alert("No Registered Patients Found")';
                            echo '</script>';
                          }
                          $con->close();
                          ?>
                          
                        </tbody>
                      </table>
<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/pr/customer/js/jquery-3.1.1.min.js"></script>
<script src="/pr/customer/js/js"></script>
<script>

</script>
</body>
</html>
