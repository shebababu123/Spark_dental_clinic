<?php
session_start();
if(isset($_SESSION['loginid'])){
  include('dbconnect.php');
  $paid=$_SESSION['loginid'];
?>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet">
    <link rel="stylesheet" href="css/admin.css">

    <link href="css/style.css" rel="stylesheet">
  <link href="css/table.css" rel="stylesheet">

    <style>
@import url(https://fonts.googleapis.com/css?family=Roboto:300);


.form {
  width: 500px;
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 500px;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: left;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Georgia", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #FFF;
  width: 100%;
  border-color: #4CAF50;
  border-radius:50px;
  padding: 15px;
  color: #4CAF50;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form button:hover,.form button:active,.form button:focus {
  background: #43A047;
  color: #FFF;
  border-color: #FFF;
  
}

.profile_pic{
    width:35%;
    float:left;

  }
  *, *:before, *:after {
    box-sizing: border-box;
}
.profile_info {
  padding: 25px 10px 10px;
  width: 65%;
  float: left;
}
.img-circle.profile_img {
  width: 70%;
  background: #fff;
  margin-left: 15%;
  z-index: 1000;
  position: inherit;
  margin-top: 20px;
  border: 1px solid rgba(52,73,94,0.44);
  padding: 4px;
}
.img-circle {
  border-radius: 50%;
}
</style>
  </head>
  <body>
    <aside class="side-nav" id="show-side-navigation1">
      <i class="fa fa-bars close-aside hidden-sm hidden-md hidden-lg" data-close="show-side-navigation1"></i>
      <div class="heading">
        
        <div class="info">
          <h3 style="font-family:georgia;"><a href="#">Spark Dental Care</a></h3>
          <p style="font-family:georgia;">Patient Panel</p>
        </div>

        <!-- menu profile quick info -->
        <div class="profile clearfix">
              <div class="profile_pic">
                <img src="images/admin.jpg" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h4 style="color:white;font-family:georgia;">
                <?php
              $con = mysqli_connect("localhost","root","","spark_dental"); 
              $sql = "SELECT * FROM tbl_patientreg WHERE Login_id = $paid";
              $sth = $con->query($sql);
              $result=mysqli_fetch_array($sth);
              $na=$result['PF_name'];
              echo "$na";
?>
                </h4>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

      <ul class="categories">
        <li><i class="fa fa-home fa-fw" aria-hidden="true"></i><a href="#"> Home</a></li>
        <li class="pc"><i class="fa fa-list-alt" aria-hidden="true"></i><a href="#">Patient Card</a></li>
        <li><i class="fa fa-list-alt" aria-hidden="true"></i><a href="#">Case Report</a>
        <ul class="side-nav-dropdown">

        <li class="acase"><a href="#">Make Case report</a></li>
        <li class="vcase"><a href="#">View Case report</a></li>

              
              </ul></li>
        <li><i class="fa fa-list-alt" aria-hidden="true"></i><a href="#">Appointment</a>
        <ul class="side-nav-dropdown">
        <li class="mappo"><a href="#">Make Apoointment</a></li>
        <li class="vappo"><a href="#">View Appointment</a></li>
    
              </ul></li>
       </ul>
    </aside>     
       <!-- <li class=""><i class="fa fa-list-alt" aria-hidden="true"></i><a href="#"></a></li>-->
       <!-- <li class="subadd"><i class="fa fa-shopping-basket" aria-hidden="true"></i><a href="#"> Add subcategory</a></li>
        <li class="apro"><i class="fa fa-shopping-basket" aria-hidden="true"></i><a href="#"> Add product</a></li>
        <li><i class="fa fa-window-close" aria-hidden="true"></i><a href="/pr/Admin/blockpro/product.php"> Block product</a></li>
        <li><i class="fa fa-window-close" aria-hidden="true"></i><a href="#"> View Stock</a></li>
        <li><i class="fa fa-window-close" aria-hidden="true"></i><a href="#"> View Sale Details</a></li>-->
     

    <section id="contents" >  
      <nav class="navbar navbar-default">
        <div class="container-fluid" style="background-color:#0b053fd7">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
              <i class="fa fa-align-right"></i>
            </button>
            <a class="navbar-brand" href="#" ><span class="main-color">Dashboard</span></a>
          </div>
          <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
              <li class="dropdown">
                <a href="\DentalClinicManagement\dentist\Patientdash\Patient\patientpro\profile.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">My profile <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="\DentalClinicManagement\dentist\Patientdash\Patient\reset\reset.php"><i class="fa fa-user-o fw"></i>Reset Password</a></li>
                  <li role="separator" class="divider"></li>
                  <li><a href="logout.php"><i class="fa fa-sign-out"></i> Log out</a></li>
                </ul>
              </li>
              <li><a href="#"><i data-show="show-side-navigation1" class="fa fa-bars show-side-btn"></i></a></li>
            </ul>
          </div>
        </div>
      </nav>
      <div class="welcome">
     <!--   <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="content">
                <h2>Patient</h2>
                 <iframe id="iloadspace" STYLE="width:100%;height:620px;" FRAMEBORDER="no" BORDER="0"  seamless="seamless" ></iframe>
          -->     <section id="get-started" class="padd-section text-center wow fadeInUp">



            <?php
            include 'dbconnect.php';
            $qu=mysqli_query($con,"SELECT a.D_specialization,b.specialization FROM tbl_adddoctor a JOIN tbl_specialization b ON a.D_specialization=b.Spec_id") or die(mysqli_error($con));
            while($qw=mysqli_fetch_array($qu))
            {
              $id=$qw['D_specialization'];
              
            }
            ?>
            <font style="font-size:27px;padding-right:5px;">Make An Appointment : </font>
             <div class="dropdown">
              <button onclick="myFunction()" class="dropbtn">select department</button>
              <div id="myDropdown" class="dropdown-content" style="width:350px;">
              <a href="booking.php?id=1">Dentistry pediatric</a>
              <a href="booking.php?id=2">Endodontis</a>
              <a href="booking.php?id=<?php echo $id;?>">Maxillofacial and oral surgery</a>
              <a href="booking.php?id=<?php echo $id;?>">Orthodontist</a>
              </div>
            </div>
          
          <script>

          /* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
          </script>

          
          
        
       

     
  

    
 </section>-->
  
              </div>
            </div>
          </div>
        </div>
      </div>

      
      
    <section class="statistics">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-4">
              
            </div>
            <div class="col-md-4">
             <Button name=book id=book>
            </div>
            <div class="col-md-4">
              
            </div>
          </div>
        </div>
      </section>
      <script src='http://code.jquery.com/jquery-latest.js'></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.js"></script>
      <script src='js/admin.js'></script>      
      <script src="getData.js"></script>
      
<script>
$(document).ready(function(){
  
  $('.mappo').click(function () { 
    
          $('.content h2').contents().replaceWith('Make Appointments');
          $('#iloadspace').attr('src','/DentalClinicManagement/dentist/Patientdash/Patient/patient.php');
           });
    $('.vappo').click(function () { 
    
    $('.content h2').contents().replaceWith('View Appointments');
    $('#iloadspace').attr('src','/DentalClinicManagement/dentist/Patientdash/Patient/viewbooking/viewbooking.php');
     });

     $('.pc').click(function () { 
    
    $('.content h2').contents().replaceWith('Patient Card');
    $('#iloadspace').attr('src','');
     });

     $('.acase').click(function () { 
    
    $('.content h2').contents().replaceWith('Add case report');
    $('#iloadspace').attr('src','C:/DentalClinicManagement/dentist/Patientdash/Patient/casereport/casereport.php');
     });
     $('.vcase').click(function () { 
    
    $('.content h2').contents().replaceWith('View case report');
    $('#iloadspace').attr('src','');
     });      
           

      });
                         
</script>
      </body>
    </html>
    <?php
}
else
{
  echo "<script>window.location.href='http://localhost/DentalClinicManagement/dentist/Signin.php';</script>";
}
?>
