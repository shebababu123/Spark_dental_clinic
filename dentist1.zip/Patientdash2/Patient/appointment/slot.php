<?php
include 'dbconnect.php';
$dayid=$_POST["day"];
$did=$_POST["did"];
$query="select a.Slot_id,a.Slot_from,a.Slot_to,b.Doctor_id,b.Day_id FROM tbl_timeslot a JOIN tbl_doctorschedule b ON a.Slot_id=b.Slot_id AND b.Day_id='$dayid' AND b.Doctor_id ='$did'";
$result=mysqli_query($con,$query);
if ( $result->num_rows > 0)
{
  echo '<option value="">Select a timeslot</option>';
    while($row = $result->fetch_assoc()) 
    {
      echo '<option value="'.$row["Slot_id"].'">'.$row["Slot_from"].' - '.$row["Slot_to"].'</option>';
    }
}
else
{
  echo '<option value="">No Slots available</option>';
}
?>