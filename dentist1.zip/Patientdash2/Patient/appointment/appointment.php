<?php
include 'dbconnect.php';
session_start();
if(isset($_SESSION['loginid'])){
  $p=$_SESSION['loginid'];
  $qu=mysqli_query($con,"select * from tbl_patientreg where Login_id='$p'") or die(mysqli_error($con));
  while($qw=mysqli_fetch_array($qu))
  {
  $pid=$qw['Patient_id'];
  echo $pid;
  }

$did=$_GET['id'];
              $qu1=mysqli_query($con,"select * from tbl_adddoctor where Doctor_id='$did'") or die(mysqli_error($con));
              while($qw1=mysqli_fetch_array($qu1))
              {
              $name=$qw1['D_name'];
              }
            
            
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Make Appointment</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="addc/img/favicon.png" rel="icon">
  <link href="addc/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Roboto:100,300,400,500,700|Philosopher:400,400i,700,700i" rel="stylesheet">

  <!-- Bootstrap css -->
  <!-- <link rel="stylesheet" href="css/bootstrap.css"> -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.theme.default.min.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/modal-video/css/modal-video.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/table.css" rel="stylesheet">
  
<style>
@import url(https://fonts.googleapis.com/css?family=Roboto:300);


.form {
  width: 500px;
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 500px;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: left;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #FFF;
  width: 100%;
  border-color: #4CAF50;
  border-radius:50px;
  padding: 15px;
  color: #4CAF50;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form button:hover,.form button:active,.form button:focus {
  background: #43A047;
  color: #FFF;
  border-color: #FFF;
  
}


</style>
</head>


<body>

  <header id="header" class="header header-hide">
    <div class="container">
    

      <div id="logo" class="pull-left">
        
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="#body"><img src="img/logo.png" alt="" title="" /></a>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
        

        </ul>
      </nav>

    </div>
  </header><!-- #header -->


  
  <section id="get-started" class="padd-section text-center wow fadeInUp">


    <div class="container">
  <div class="section-title text-center">
      <div class="login-page" style="padding-top:150px;">
          <div class="form">
            <form class="login-form" action="" method="POST" id="reg" autocomplete="off" style="font-family: Georgia ;">
                			
	    				<div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label"style="padding-right: 10px; padding-left: 10px;color: Black;font-size: 20px;">Doctor Name: </label>
							
              <label name="dname" style="color:Black;"><?php echo $name ?></label>
							</div>
              </div>
            
              <div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label" style="padding-right: 10px; padding-left: 10px;color: Black;font-size: 20px;">Day:</label>
							
							
		                    <select name="day" id="day" class="form-control" style="width: 220px;">
		                      	<option value="">Select a Day</option>
                <?php
                $q3="SELECT DISTINCT a.Day_id,b.day FROM tbl_doctorschedule a JOIN tbl_days b ON a.Day_id = b.Day_id AND a.Doctor_id='$did'";
                
								$ch3=mysqli_query($con,$q3);
								while($data=mysqli_fetch_array($ch3))
								{
                 echo '<option value="'.$data["Day_id"].'">'.$data["day"].'</option>'; 
                }
								?>
		            </select>
              <input type="hidden" name="did" id="doctorid" value="<?php echo $did; ?>">
              </div>
              </div>

              <div class="d-flex">
	    					<div class="form-group mr-2">
							    <label for="" class="label" style="padding-right: 10px; padding-left: 10px;color: Black;font-size: 20px;">Timeslot:</label>
							
		                    <select name="slot" id="slot" class="form-control" style="width: 220px;">
		                      	<option value="">Select a timeslot</option>
		                    </select>
                    </div>
                </div>
              
	    			<br>	
            <div class="d-flex">
	    					<div class="form-group mr-2">
							<label for="" class="label"style=" padding-left: 10px;color: Black;font-size: 20px;">Date: </label>
							
              <!--label name="date" style="color:Black;"></label>-->
              <input type="text" name="da" value="<?php echo $date= date("Y-m-d");  ?>">
							</div>
              </div>
	            		<div class="group" align="center">
	              			<p><a href="bokkingpayment.php?pa=<?php echo $pid;?>"><input type="submit" name="submit" align="middle" value="Appointment" id="submit" style="font-size: 16px; background: #DE006F;width: 170px;" class="btn btn-primary py-3 px-4"></a></p>
	            		</div>
            </form>
       </div>
     </div>
</div>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
    jQuery.validator.addMethod("noSpace", function(value, element) { 
    return value == '' || value.trim().length != 0;  
}, "No space please and don't leave it empty");
jQuery.validator.addMethod("phonenum", function(value, element) { 
    return this.optional( element ) || /^([7-9_\.\-])+(([0-9]))+$/.test( value ); 
}, "Please enter valid phone number");
jQuery.validator.addMethod("customEmail", function(value, element) { 
  return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.))+([a-zA-Z0-9]{2,4})+$/.test( value ); 
}, "Please enter valid email address!");

$.validator.addMethod("alphabetsnspace", function(value, element) {
        return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
    });


$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, numbers, and underscores only please" );
var $ureg = $('#reg');
if($ureg.length){
  $ureg.validate({
      rules:{
          //username is the name of the textbox
         
        day:{
                required: true
                },
        slot:{
                required: true
                },		
          
      },
      messages:{
          
          day: {
            required:'Please select a day!'
          },
          slot: {
              required: 'Please select a slot !'
          },    
          
      },
      
  });
}


  </script>	

<?php 
		include 'dbconnect.php';
			if(isset($_POST['submit']))
			{
             
            $day=$_POST['day'];
            $slot=$_POST['slot'];
            $d=$_POST['da'];
            

				$sq1="INSERT INTO `tbl_appointment1`(`Doctor_id`, `Patient_id`, `Day_id`, `Slot_id`, `Date`) VALUES ('$did','$pid','$day','$slot','$d')";
        
        echo $sq1;
        $ch=mysqli_query($con,$sq1);
				if($ch)
				{
  				?>
   				<script>
 				alert("Appointment Successfully");
				window.location="bokkingpayment.php";
				</script>
				<?php
				}
				else
				{
  				echo"error:".$sq1."<br>".mysqli_error($con);
				}
				}
				
			
				mysqli_close($con);
				?>



    <div class="container">
      <div class="row">

        
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/modal-video/js/modal-video.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="js/main.js"></script>
  <script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
 			<script src="js/jquery-ui.js"></script>			
			<script src="js/owl.carousel.min.js"></script>						
			<script src="js/jquery.nice-select.min.js"></script>							
			<script src="js/mail-script.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="addc/contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="addc/js/main.js"></script>
  <script src="slot.js"></script>

</body>
</html>


<?php
}
else
{
  echo "<script>window.location.href='http://localhost/DentalClinicManagement/dentist/Signin.php';</script>";
}
?>