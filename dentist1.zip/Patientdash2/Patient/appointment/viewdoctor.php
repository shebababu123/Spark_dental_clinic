<html>
<head>
<link rel="stylesheet" href="\DentalClinicManagement\dentist\Patientdash\Patient\appointment\css\customerview.css">
<nav id="nav-menu-container">
        <ul class="nav-menu">
          

        </ul>
      </nav>
</head>
<body>
 <table>
 
     <thead>
            <tr>
               <th colspan="6" align="center" style="font-size:30px;color:white;">View Doctors</th>
            </tr>
            <tr style="background-color:#2b3d27e8;">
                <th>Index.</th>
                <th>Fullname</th>
                <th>Gender</th>
                <th>Specialization</th>
                <th>Action</th>
                
            </tr>
    </thead>
          <tbody>
                          <?php 
                          include "dbconnect.php";
                          $query="select * from tbl_adddoctor";
                          $result = mysqli_query($con,$query) or die(mysqli_error());
                         if ($result->num_rows > 0)
                          {
                            $i=1;
                            while($row = $result->fetch_assoc()) 
                            {
                                $name=$row['D_name'];
                                $gender=$row['D_gender'];
                                $speci=$row['D_specialization'];
                           echo "<tr style='color:black;'><td>".$i."</td><td>$name</td><td>$gender</td><td>$speci</td>";?>
                          
                          <td>
                          <a href="/DentalClinicManagement/dentist/Patientdash/Patient/appointment/appointment.php?id=<?php echo $row["Doctor_id"]; ?>" ><button class="book">BOOK</button></a> 
                          </td></tr>
                          <?php
                           
                           ++$i;
                          }
                            }
                        
                          else
                          {
                            echo '<script language="javascript">';
                            echo 'alert("No doctors Found")';
                            echo '</script>';
                          }
                          $con->close();
                          ?>
                        </tbody>
                      </table>
<script src='http://code.jquery.com/jquery-latest.js'></script>
<script src="/pr/customer/js/jquery-3.1.1.min.js"></script>
<script src="/pr/customer/js/js"></script>
<script>

</script>
</body>
</html>
