$('#day').on('change', function() {
  var docid=$('#doctorid').val();
  var dayyid=this.value ;
  $.ajax({
    url: "/DentalClinicManagement/dentist/Patientdash/Patient/appointment/slot.php",
    type: "POST",
    data: {day : dayyid,did : docid},
    success: function (response) {
      $('#slot').html(response);
    }
  });
});