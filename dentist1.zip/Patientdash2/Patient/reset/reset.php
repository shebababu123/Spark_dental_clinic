<?php
session_start();
$email=$_SESSION['email'];
?>
<!DOCTYPE HTML>
<!--
	Eventually by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>RESET PASSWORD</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="css/reset.css" />
	</head>
	<body class="is-preload">
	
			
		<!-- Header -->
			<head>
				
				<center><h1>RESET PASSWORD</h1>
					</head></center>
				
		<div class="back">
			<a href="\DentalClinicManagement\dentist\Patientdash\Patient\patient.php"><font style="font-size:20px">Home</font></a>
		</div>
		<!-- Signup Form -->
		<div class="wrapper">
			<form class="form-signin" action="" method="POST" >       
			  <h2 class="form-signin-heading">Reset Password</h2>
			  <input type="password" class="form-control" id="newpassword"  name="newpassword" placeholder="Enter New Password" autocomplete="off" />
			  <input type="password" class="form-control" id="cnewpassword" name="confirm" placeholder="Confirm New Password" autocomplete="off" />     
			  <button class="btn btn-lg btn-primary btn-block" id="reset_psw" name="reset">Reset Password</button>   
		</form>
		  </div>
		  <?php
				include "dbconnect.php";
	 
				if(isset($_POST['reset']))
				{
				$new1=$_POST["newpassword"];
				$new=md5('$new1');
				$conf=$_POST["confirm"];
				$re= mysqli_query($con,"select * from tbl_login where L_email='$email'");
				
				
				if(mysqli_num_rows($re)>0)
				{
					
					if ($new1==$conf)
					{ 
					mysqli_query($con,"update tbl_login set L_password='$new' where L_email='$email'");
					?>
						<script>
						alert("successfully updated")
						</script>
						<?php
					}
					else
					{
						?>
						<script>
						alert("Password MisMatch")
						</script>
					
				<?php
					}
				}
				else
				{
					
					?>
					
					<script>
					alert("Password Does not exists")
					</script>    
					<?php }
				}?>
		  
		

		  <script src="jquery-3.1.1.min.js"></script>
		  <script src="reset.js"></script>
		  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	</body>
</html>