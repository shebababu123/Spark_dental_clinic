<?php
include 'dbconnect.php';

 
 $p=$_GET['id'];
          $qu=mysqli_query($con,"SELECT a.D_photo,a.D_name,a.Doctor_id,a.D_specialization,b.specialization FROM tbl_adddoctor a JOIN tbl_specialization b ON a.D_specialization=b.Spec_id AND D_specialization='$p'") or die(mysqli_error($con));
          $qw=mysqli_fetch_array($qu);
          $dname=$qw['D_name'];
          $spe=$qw['specialization'];
          $d=$qw['Doctor_id'];
         
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="slot.js"></script>
  <script>
  $(document).ready(function() {
  $("#datepicker").datepicker({
      dateFormat: 'yy-mm-dd'

  });
  $('.fa-calendar').click(function() {
    $("#datepicker").focus();
  });
});
  </script>
  <style>
      .form {
  width: 500px;
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 500px;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: left;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #FFF;
  width: 100%;
  border-color: #4CAF50;
  border-radius:50px;
  padding: 15px;
  color: #4CAF50;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form button:hover,.form button:active,.form button:focus {
  background: #43A047;
  color: #FFF;
  border-color: #FFF;
  
}
.profile_pic{
  width:35%;
  float:left;

}
*, *:before, *:after {
  box-sizing: border-box;
}
.profile_info {
padding: 25px 10px 10px;
width: 65%;
float: left;
}
.img-circle.profile_img {
width: 70%;
background: #fff;
margin-left: 15%;
z-index: 1000;
position: inherit;
margin-top: 10px;
border: 1px solid rgba(52,73,94,0.44);
padding: 4px;
}
.img-circle {
border-radius: 50%;
}
  </style>
</head>
<body>
    <div class="form">
        <form class="login-form" action="" method="POST" id="reg" autocomplete="off" style="font-family: Georgia ;">
                        
            <div class="d-flex">
                <div class="form-group mr-2">    			
                    <div class="profile clearfix">
                        <div class="profile_pic">   			
                                <?php
                                    include 'dbconnect.php';          
       
                                    $imag=mysqli_query($con,"select D_photo from tbl_adddoctor where D_specialization='$p'");
                                    while($r=mysqli_fetch_array($imag))
                                    {
                                        $img=$r['D_photo'];
                                        echo '<img src="data:D_photo/jpg;base64,'.base64_encode($img).'" class="img-circle profile_img">';
                                    }
                                ?>
                        </div>
                    </div>
                                
                        <label name="dname" style="color:Black;font-size: 20px;"><?php echo $dname; ?></label><br>

                </div>
            </div>
    <div class="col-md-4 col-sm-4 col-xs-12">
<input type="text" id="datepicker" name="datepicker" class="form-control" ng-required="true" value="Select date">
<span class="fa fa-calendar"></span>

 </div>
 <select name="slot" id="slot" class="form-control" style="width: 250px;height:35px;background-color:#f2f2f2;">
		                    <option value="">Select a slot</option>
		                </select>
  <input type="hidden" name="nm" id="did" value="<?php echo $d; ?>">
 
</form>
</div>

 
</body>
</html>