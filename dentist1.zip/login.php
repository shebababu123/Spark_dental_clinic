<?php 
session_start(); 
$email="";
$pass="";
$db = mysqli_connect('localhost', 'root', '', 'spark_dental');
if(isset($_POST['submit']))
{
  $email =$_POST['email'];
  $passn =$_POST['pass'];
	$pass=md5($passn);

$sql="SELECT * FROM `tbl_Login` WHERE L_email='$email'";


$res = mysqli_query($db, $sql);
if(mysqli_num_rows($res)>0)
{
   while($row=  mysqli_fetch_assoc($res))
   {
     $dbu_email=$row['L_email'];
    $dbu_pass=$row['L_password'];
    $dbu_type=$row['L_usertype'];
    //$dbu_stat=$row['status'];
if($dbu_email== $email && $dbu_pass == $pass)
    {
      
      if($dbu_type==0) 
      {
        
	   $_SESSION['loginid']=$row[Login_id];
	   $_SESSION['email']=$row[L_email];

	  header('Location:http://localhost/DentalClinicManagement/dentist/Admindash/Admin/admin.php');
	  
	

      
	  }
     else if($dbu_type==1)
      {
        $_SESSION['loginid']=$row[Login_id];
        $_SESSION['email']=$row[L_email];
		
        header('Location: http://localhost/DentalClinicManagement/dentist/Patientdash/Patient/patient.php');
      }
	 /*   else if($dbu_type==1 && $dbu_stat==2)
      {
		  echo '<script language="javascript">';
          echo 'alert(" You are not aproved by admin ")';
          echo '</script>';
          echo "<script>window.location.href='index.html'</script>";
        
      } */
	   /*  else if($dbu_type==1 && $dbu_stat==0)
      {
		  echo '<script language="javascript">';
          echo 'alert(" You are not aproved by admin ")';
          echo '</script>';
        echo "<script>window.location.href='index.html'</script>";
      } */
	 
      else if($dbu_type==2)
      {
       
	   $_SESSION['loginid']=$row[Login_id];
	   $_SESSION['email']=$row[L_email];
	   
        header("location:http://localhost/DentalClinicManagement/dentist/Doctordash/Doctor/doctor.php");
      }
      else if($dbu_type==3)
      {
       
	   $_SESSION['loginid']=$row[Login_id];
	   $_SESSION['email']=$row[L_email];
	   
        header("location:http://localhost/DentalClinicManagement/dentist/Pharmacistdash/Pharmacist/pharmacist.php");
      }
      else if($dbu_type==4)
      {
       
	   $_SESSION['loginid']=$row[Login_id];
	   $_SESSION['email']=$row[L_email];
	   
        header("location:http://localhost/DentalClinicManagement/dentist/Recedash/Receptionist/receptionist.php");
      }

	}
    else
        {
      
          echo '<script language="javascript">';
          echo 'alert("Email or Password is incorrect ")';
          echo '</script>'; 
		  
		 }
      }
	   echo "<script>window.location.href='http://localhost/DentalClinicManagement/dentist/Signin.php'</script>";
    }
  else
        {
      
          echo '<script language="javascript">';
          echo 'alert("Username or Password is incorrect ")';
          echo '</script>'; 
		  
		 }
		 echo "<script>window.location.href='http://localhost/DentalClinicManagement/dentist/Signin.php'</script>";
  }
  
else
{
     
	 echo '<script language="javascript">';
    echo 'alert("User Not Found")';
    echo '</script>';
   echo "<script>window.location.href='http://localhost/DentalClinicManagement/dentist/Signin.php'</script>";


}
    
